////////////////////////////////////////////////////////////
// Listing 12 aus Kapitel 3
// Liste, Knoten und Element

typedef int ELEMENT;

class Knoten
{
};

class Liste
{
};
