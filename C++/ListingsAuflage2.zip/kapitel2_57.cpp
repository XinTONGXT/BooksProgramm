////////////////////////////////////////////////////////////
// Listing 57 aus Kapitel 2
// Zugriffsversuch auf die Elemente der Klasse

Punkt p;
p.x = 0; // Compilefehler!
p.y = 0; // Compilefehler!
