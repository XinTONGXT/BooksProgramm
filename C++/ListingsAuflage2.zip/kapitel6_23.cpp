////////////////////////////////////////////////////////////
// Listing 23 aus Kapitel 6
// Schritt 3: Der Operator << kommt aus std

#include <iostream>
#include <string>
	
int main()
{
	std::string str = "Na sowas!";

	std::operator<<(std::cout,str);

	return 0;
}
