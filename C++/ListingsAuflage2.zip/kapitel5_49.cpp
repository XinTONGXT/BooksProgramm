////////////////////////////////////////////////////////////
// Listing 49 aus Kapitel 5
// Verschiedene Konstruktoren der Stringklasse

#include <iostream>
#include <string>

int main()
{
    using namespace std;

    string str1( "Ostern" );
    string str2 = "in Madeira";
    string str3;
    string str4( str1, 0, 5 );
    string str5( str2, 6, 2 );
    string str6 = str4 + str5;

    cout << str6 << endl;

    return 0;
}
