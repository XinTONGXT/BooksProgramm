////////////////////////////////////////////////////////////
// Listing 3 aus Kapitel 6
// Einhaltung einer Inklusionsreihenfolge

// Header DB.h
class DBZugriff
{
	// ...
};
// Ende DB.h

// Header DBDialog.h
class DBDialog
{
	DBZugriff *zugriff;
	// ...
};
// Ende DBDialog.h

// Applikation.cpp
#include "DB.h"         // Diese Datei muss vor
#include "DBDialog.h"   // jener inkludiert werden!

int OpenDBDialog()
{
	DBDialog dlg;
	// ...
}
// Ende Applikation.cpp
