////////////////////////////////////////////////////////////
// Listing 21 aus Kapitel 2
// Array-Syntax

	short buffer[100];
	short *p;

	p = &buffer[2];
	p += 5;
	/* p zeigt jetzt auf buffer[7] */
