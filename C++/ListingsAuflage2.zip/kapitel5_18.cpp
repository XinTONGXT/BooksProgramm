////////////////////////////////////////////////////////////
// Listing 18 aus Kapitel 5
// Eine Demonstration des STL-Vektors

#include <iostream>
#include <vector>

int main()
{
	std::vector<int> l;

	l.push_back( 3 );
	l.push_back( 5 );
	l.push_back( 7 );

	for( std::vector<int>::iterator it = l.begin();
	     it != l.end();
	     ++it )
	     std::cout << *it << std::endl;

	return 0;
}
