////////////////////////////////////////////////////////////
// Listing 55 aus Kapitel 4
// Ein Referenzz�hler

class RefCounter
{
public:
    RefCounter() : n(0) {}
    void Inc() { n++; }
    void Dec() { n--; }
    bool IsZero() const { return n == 0; }
private:
    unsigned int n;
// Copy-Konstruktor und Zuweisungsoperator verstecken!
    RefCounter( const RefCounter & );
    RefCounter &operator=( const RefCounter & );
};
