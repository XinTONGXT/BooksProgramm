////////////////////////////////////////////////////////////
// Listing 104 aus Kapitel 2
// Verschachtelte Klasse

class Toyota
{
public:
	// ...

	class ToyotaWagenheber
	{
		// ...
	};
};
