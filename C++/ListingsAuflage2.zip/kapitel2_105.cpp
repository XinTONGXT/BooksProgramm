////////////////////////////////////////////////////////////
// Listing 105 aus Kapitel 2
// Instanziierung einer verschachtelten Klasse

// ...
Toyota::ToyotaWagenheber objekt;
// ...
