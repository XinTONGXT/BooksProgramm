////////////////////////////////////////////////////////////
// Listing 46 aus Kapitel 4
// Vorgabetypen in Template-Templateparametern

template<typename T, typename S>
class A {};

template< template < typename Q,
                     typename R = Q*
        > class T >
class X
{
    T<int> t;
};
