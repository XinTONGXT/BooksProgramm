////////////////////////////////////////////////////////////
// Listing 9 aus Kapitel 4
// Template-Implementierung einer Inline-Funktion

template <class T>
inline const T& min( const T &a, const T &b )
{
	return (a < b) ? a : b;
}
