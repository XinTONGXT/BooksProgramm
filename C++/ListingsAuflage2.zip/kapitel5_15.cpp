////////////////////////////////////////////////////////////
// Listing 15 aus Kapitel 5
// Anwendung des istringstream zur Eingabe aus Strings

#include <iostream>
#include <sstream>

struct Complex
{
	double r;
	double i;
};

std::istream& operator>>( std::istream &is, Complex &c )
{
	is >> c.r;
	is >> c.i;
	return is;
}

std::ostream& operator<<( std::ostream &os,
                          const Complex &c )
{
	return os << "(" << c.r << "/i" << c.i << ")";
}

int main()
{
	using namespace std;
	string txt = "5 3";
	istringstream str(txt);

	Complex c;

	str >> c;

	cout << c << endl;

	return 0;
}
