////////////////////////////////////////////////////////////
// Listing 17 aus Kapitel 3
// Die Zugriffsklasse

class Zugriff
{
public:
	Zugriff( Knoten *pk ) : k(pk) {}
	void Inc() { k = k->next; }
	void Dec() { k = k->prev; }
	bool IsValid() const { return k != 0; }
private:
	Knoten *k;
};
