////////////////////////////////////////////////////////////
// Listing 20 aus Kapitel 2
// Array-Syntax

	short buffer[100];
	short *p;

	p = &buffer[0];
	p++;
	/* p zeigt jetzt auf buffer[1] */
