////////////////////////////////////////////////////////////
// Listing 23 aus Kapitel 4
// Methodentemplate mit partieller Spezialisierung

template <typename T1, typename T2>
class X
{
public:
	void f();
};

template <typename T1, typename T2>
void X<T1,T2>::f()
{
// Tu was...
}

template <typename T1>
class X<T1,int>
{
public:
	void f();
};

template <typename T1>
void X<T1,int>::f()
{
// Tu was...
}
