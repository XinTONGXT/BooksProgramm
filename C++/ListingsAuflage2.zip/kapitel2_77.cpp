////////////////////////////////////////////////////////////
// Listing 77 aus Kapitel 2
// Initialisierung eines Referenzobjekts

class Logging
{
public:
	Logging( std::ostream _os ) : os(os) {}

	void schreibe( char *txt )
	{
		os << txt << std::endl;
	}

private:
	std::ostream &os;
};
