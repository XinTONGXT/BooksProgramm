////////////////////////////////////////////////////////////
// Listing 49 aus Kapitel 4
// Anpassung von Template-Templateparametern f�r ein bestimmtes �bergabetemplate

template< typename K,
          typename V,
          template <
                    typename T,
                    typename = std::allocator<T>
                   > class C >
class Mapping;
