////////////////////////////////////////////////////////////
// Listing 91 aus Kapitel 2
// Dynamische Instanziierung

#include <iostream>

class X
{
public:
	X() { std::cout << "X::X()" << std::endl; }
	~X() { std::cout << "X::~X()" << std::endl; }
};

int main()
{
	try
	{
		X *p = new X;

		delete p;
	}
	catch( std::bad_alloc &e )
	{
		// Fehlerfall
	}

	return 0;
}
