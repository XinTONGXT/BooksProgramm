////////////////////////////////////////////////////////////
// Listing 4 aus Kapitel 5
// Definition und Anwendung eines Eingabeoperators

#include <iostream>
#include <fstream>

struct Complex
{
	double r;
	double i;
};

std::istream& operator>>( std::istream &is, Complex &c )
{
	is >> c.r;
	is >> c.i;
	return is;
}


std::ostream& operator<<( std::ostream &os,
                          const Complex &c )
{
	return os << "(" << c.r << "/i" << c.i << ")";
}

int main()
{
	Complex c;

	std::cout << "Eingabe einer Komplexen Zahl: ";
	std::cin >> c;
	std::cout << "Die Komplexe Zahl: " << c << std::endl;

	return 0;
}
