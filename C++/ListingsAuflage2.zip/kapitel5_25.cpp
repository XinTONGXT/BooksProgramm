////////////////////////////////////////////////////////////
// Listing 25 aus Kapitel 5
// Ein Demobeispiel zur STL-Queue

#include <iostream>
#include <string>
#include <list>
#include <deque>
#include <queue>

template <typename Q>
void WriteOut( Q &q )
{
	using std::cout;
	using std::endl;
	while( q.size() )
	{
		cout << q.front() << endl;
		q.pop();
	}
}

int main()
{
	using namespace std;
	queue< string, list<string> >  lq;
	queue< string, deque<string> > dq;

	lq.push( "Kartoffel" );
	lq.push( "Kohlrabi" );
	lq.push( "Zwiebel" );

	dq.push( "Bohne" );
	dq.push( "Linse" );
	dq.push( "Erbse" );

	WriteOut( lq );
	cout << "***" << endl;
	WriteOut( dq );

	return 0;
}
