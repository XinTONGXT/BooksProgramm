////////////////////////////////////////////////////////////
// Listing 29 aus Kapitel 6
// �berladener new-Operator mit Fehlerroutine

class X
{
public:
  void* operator new( size_t, new_handler );
  // ...
};
