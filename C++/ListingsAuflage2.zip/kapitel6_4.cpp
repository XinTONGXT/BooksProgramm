////////////////////////////////////////////////////////////
// Listing 4 aus Kapitel 6
// Die Deklaration der Klasse DBZugriff

// Header DB.h
class DBZugriff
{
public:
	void init();
	// ...
};
// Ende DB.h
