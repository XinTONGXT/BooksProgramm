////////////////////////////////////////////////////////////
// Listing 136 aus Kapitel 2
// Dynamische Verschiebung der Objektadresse beim dynamischen Upcast

#include <iostream>

class A { public: int a; };
class B1 : virtual public A { public: int b1; };
class B2 : public virtual A { public: int b2; };
class B3 : public virtual A { public: int b3; };

class C : public B1, public B2 { public: int c; };
class D : public C, public B3 {};

void f( C* pc );

int main()
{
    C c;
    D d;

    f( &c );
    f( &d );
    std::cout << ((A*)&d) << std::endl;

    return 0;
}

void f( C* pc )
{
    A *pa = pc;
    std::cout << pc << std::endl;
    std::cout << pa << std::endl;
}
