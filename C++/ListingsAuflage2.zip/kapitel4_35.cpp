////////////////////////////////////////////////////////////
// Listing 35 aus Kapitel 4
// Der Problemcode

template <class T>
class X { /* ... */ };

template <class T>
class Y { /* ... */ };

template <class T>
void f( X<T> )
{
	// ...
}

template <class T>
void f( Y<T> )
{
	// ...
}
