////////////////////////////////////////////////////////////
// Listing 97 aus Kapitel 2
// M�gliches Ergebnis einer Compileroptimierung

if( !a )
{
	sprungmarke:
	Sleep( 1 ); // 1 Millisekunde
	ticks++;
	goto sprungmarke;
}
