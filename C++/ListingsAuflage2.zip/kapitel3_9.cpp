////////////////////////////////////////////////////////////
// Listing 9 aus Kapitel 3
// Definition eines auf Templates basierenden W�chters

template <class T>
class SingletonWaechter {
  T* singleton;

public:
  SingletonWaechter()
  {
    singleton = new T;
  }

  ~SingletonWaechter()
  {
    if (singleton != 0)
      delete singleton;
  }

  T* instance() const
  {
    return singleton;
  }
};

class CppClass {
public:
  static CppClass* getInstanz();

private:
  CppClass() {}
  CppClass(const CppClass& other);
  ~CppClass() {}

  friend class SingletonWaechter<CppClass>;
};

CppClass* CppClass::getInstanz()
{
  static SingletonWaechter<CppClass> w;
  return w.instance();
}

int main()
{
	CppClass *p = CppClass::getInstanz();

	return 0;
}
