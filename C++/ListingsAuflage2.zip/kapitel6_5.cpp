////////////////////////////////////////////////////////////
// Listing 5 aus Kapitel 6
// Vorw�rtsdeklaration und Verwendung der Klasse DBZugriff

// Header DBDialog.h

class DBZugriff; // Vorw�rtsdeklaration

class DBDialog
{
	DBZugriff *zugriff; // Hier wird keine vollst�ndige
	                    // Typeninformation gebraucht.

	// Die nachfolgende, auskommentierte Methode k�nnte
	// nicht �bersetzt werden, da sie die Typeninformation
	// der Klasse DBZugriff ben�tigte.
	// void open() { zugriff->init(); }

	void open(); // Nur die Deklaration!
	// ...
};
// Ende DBDialog.h
