////////////////////////////////////////////////////////////
// Listing 118 aus Kapitel 2
// Einfache Methode

class Grafikelement
{
public:
	void zeichne( Zeichenflaeche *zf );
};
