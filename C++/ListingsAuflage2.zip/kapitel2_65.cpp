////////////////////////////////////////////////////////////
// Listing 65 aus Kapitel 2
// Inlining von Methoden

class X
{
public:
	X() { /* ... */ }	// Inline Konstruktor
	~X() { /* ... */ } // Inline Destruktor
	void f() { /* ... */ }	// Inline Methode
};
