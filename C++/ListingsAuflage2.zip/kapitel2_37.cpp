////////////////////////////////////////////////////////////
// Listing 37 aus Kapitel 2
// Inklusionsbeziehungen zur Sicherung des passenden Funktionsaufrufs

// Datei F.H
int f1( int );

// Datei F.CPP
#include "F.H"

int f1( int wert )
{
  return wert * 2;
}

// Datei MAIN.CPP
#include <iostream>
#include "F.H"

int main()
{
	st::cout << f1( 21 ) << std::endl;

	return 0;
}
