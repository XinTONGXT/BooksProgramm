////////////////////////////////////////////////////////////
// Listing 29 aus Kapitel 2
// Implizite Typenkonvertierung in einem Ausdruck

	int i = 5;
	double d = 7.3;
	double e;
	/* Implizite Konvertierung des Wertes i nach double */
	e = i + d;
