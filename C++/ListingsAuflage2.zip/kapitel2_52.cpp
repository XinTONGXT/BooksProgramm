////////////////////////////////////////////////////////////
// Listing 52 aus Kapitel 2
// Anwendung des Pfeiloperators

struct Punkt p1;
struct Punkt *pp;
pp = &p1;
pp->x = 0;
pp->y = 0;
