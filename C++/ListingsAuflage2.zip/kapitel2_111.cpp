////////////////////////////////////////////////////////////
// Listing 111 aus Kapitel 2
// Vererbung

class Fahrzeug
{
public:
	int geschwindigkeit;
};

class Auto : public Fahrzeug
{
};

class Schiff : public Fahrzeug
{
};
