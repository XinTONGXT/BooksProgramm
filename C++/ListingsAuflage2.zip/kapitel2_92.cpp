////////////////////////////////////////////////////////////
// Listing 92 aus Kapitel 2
// Dynamische Instanziierung nach AT&T-Standard

#include <iostream.h>

class X
{
public:
	X() { cout << "X::X()" << endl; }
	~X() { cout << "X::~X()" << endl; }
};

int main()
{
	X *p = new X;
	if( p != NULL )
	{
		delete p;
	}
	else
	{
		// Fehlerfall
	}

	return 0;
}
