////////////////////////////////////////////////////////////
// Listing 18 aus Kapitel 4
// Deklaration und Implementierung eines Membertemplates

template <typename T, unsigned n>
class Array
{
public:
	enum { size = n };

	// ...

	template <typename C >
	     void copy_from( const C &c );
private:
    T data[n];
};

template<typename T, unsigned n>
 template<typename C>
	void Array<T,n>::copy_from( const C &c )
	{
		int i = 0;
		typename C::const_iterator it = c.begin();
		while( i < n && it != c.end() )
		{
			data[i++] = *it;
			++it;
		}
	}
