////////////////////////////////////////////////////////////
// Listing 93 aus Kapitel 2
// Die nothrow-Variante des new-Operators

#include <iostream>
using namespace std;

class X
{
public:
	X() { cout << "X::X()" << endl; }
	~X() { cout << "X::~X()" << endl; }
};

int main()
{
	X *p = new(nothrow) X;
	if( p != NULL )
	{
		delete p;
	}
	else
	{
	}

	return 0;
}
