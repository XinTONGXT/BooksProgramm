////////////////////////////////////////////////////////////
// Listing 73 aus Kapitel 4
// Compilezeit-Assertion aus cite{Alexandrescu01

template <bool> struct CompileTimeError;
template <> struct CompileTimeError<true> {};
#define CT_CHECK(expression) \
        (CompileTimeError<(expression) != 0>())
