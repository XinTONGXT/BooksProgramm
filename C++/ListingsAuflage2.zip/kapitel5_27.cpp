////////////////////////////////////////////////////////////
// Listing 27 aus Kapitel 5
// Erstes Beispiel zu einem Stream-Iterator

#include <fstream>
#include <iterator>
#include <string>

int main()
{
	using namespace std;

	ofstream outd( "test.txt" );
	ostream_iterator<string> outs( outd );

	*outs = "Die erste Zeile Text\n";
	++outs;
	*outs = "Die zweite Zeile Text\n";
	++outs;
	*outs = "Die dritte Zeile Text\n";

	return 0;
}
