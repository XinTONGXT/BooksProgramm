////////////////////////////////////////////////////////////
// Listing 62 aus Kapitel 4
// Explizite Instanziierung einer Templateklasse

template class X<int>;
