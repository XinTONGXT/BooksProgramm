////////////////////////////////////////////////////////////
// Listing 48 aus Kapitel 6
// Allgemeine Syntax zur volatile-Spezifikation

class X
{
public:
	void f() volatile;
};

void X::f() volatile
{
  // ...
}

int main()
{
	volatile X obj;
	
	obj.f();

	return 0;
}
