////////////////////////////////////////////////////////////
// Listing 26 aus Kapitel 6
// Die Benutzung eines Templates in mehreren Modulen

// Modul F1.CPP
#include "MIN.H"
int f1( int a, int b )
{
  // ...
  int x = min( a, b );
  // ...
}

// Modul F2.CPP
#include "MIN.H"
int f2( int a, int b )
{
  // ...
  int x = min( a, b );
  // ...
}
