////////////////////////////////////////////////////////////
// Listing 49 aus Kapitel 6
// Allgemeine Syntax zur const- und volatile-Spezifikation

class X
{
public:
	void f() const volatile;
};

void X::f() const volatile
{
	// ...
}

int main()
{
	volatile X obj;

	obj.f();

	return 0;
}
