////////////////////////////////////////////////////////////
// Listing 26 aus Kapitel 5
// Ein Demobeispiel zur STL-Priority Queue

#include <iostream>
#include <string>
#include <vector>
#include <deque>
#include <queue>

template <typename Q>
void WriteOut( Q &q )
{
	using std::cout;
	using std::endl;
	while( q.size() )
	{
		cout << q.top() << endl;
		q.pop();
	}
}

int main()
{
	using namespace std;
	priority_queue< string, vector<string> > vq;
	priority_queue< string, deque<string> >  dq;

	vq.push( "Erdbeere" );
	vq.push( "Apprikose" );
	vq.push( "Kirsche" );

	dq.push( "Bohne" );
	dq.push( "Linse" );
	dq.push( "Erbse" );

	WriteOut( vq );
	cout << "***" << endl;
	WriteOut( dq );

	return 0;
}
