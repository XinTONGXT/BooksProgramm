////////////////////////////////////////////////////////////
// Listing 26 aus Kapitel 2
// Implizite Typenkonvertierung

	long i;
	double d;
	// ...
	i = 42;
	d = i;
