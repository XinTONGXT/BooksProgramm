////////////////////////////////////////////////////////////
// Listing 37 aus Kapitel 6
// Schematische Deklaration zur Persistenz

class PersistenzObjekt
{
public:
	virtual ~PersistenzObjekt();

	virtual void schreibe( std::ostream & ) = 0;
};
