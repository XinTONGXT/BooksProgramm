////////////////////////////////////////////////////////////
// Listing 10 aus Kapitel 3
// Eine 1-zu-3-Komposition

class A
{
	// ...
};

class B
{
public:
	// ...
private:
	A a1, a2, a3;
};
