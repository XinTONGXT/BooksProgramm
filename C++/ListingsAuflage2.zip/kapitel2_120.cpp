////////////////////////////////////////////////////////////
// Listing 120 aus Kapitel 2
// Virtuelle Methode

// Pseudocode
class Grafikelement
{
public:
	virtual void zeichne( Zeichenflaeche *zf );
};
