////////////////////////////////////////////////////////////
// Listing 17 aus Kapitel 2
// Zeigertypenkonflikt

	double d;
	int *p;
	
	p = &d; /* Compilierfehler! */
