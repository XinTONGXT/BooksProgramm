////////////////////////////////////////////////////////////
// Listing 3 aus Kapitel 3
// Singleton mit privatem Kopierkonstruktor

class Singleton
{
   public:
     static Singleton* exemplar();

   protected:
     Singleton() {}

   private:
     static Singleton *instanz;
     Singleton( const Singleton& );
};

...
