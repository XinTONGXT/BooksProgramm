////////////////////////////////////////////////////////////
// Listing 28 aus Kapitel 4
// Qualifizierter Aufruf eines Operators

if( p1.operator==( p2 ) )
{
	// ...
}
