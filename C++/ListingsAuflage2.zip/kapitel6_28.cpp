////////////////////////////////////////////////////////////
// Listing 28 aus Kapitel 6
// �berladener new-Operator

class X
{
public:
  void* operator new( size_t );
  // ...
};
