////////////////////////////////////////////////////////////
// Listing 38 aus Kapitel 4
// Die L�sung

template <class T>
class X
{
	// ...
	friend void f( X<T> )
	{
		// ...
	}
};

template <class T>
class Y
{
	// ...
	friend void f( Y<T> )
	{
		// ...
	}
};
