////////////////////////////////////////////////////////////
// Listing 36 aus Kapitel 5
// Standardkonforme Deklaration eines Pr�dikats

class compare
: public std::binary_function<int,int,bool>
{
public:
    bool operator()( int i, int v ) const
    {
        return i == v;
    }
};
