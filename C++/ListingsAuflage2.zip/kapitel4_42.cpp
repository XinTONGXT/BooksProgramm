////////////////////////////////////////////////////////////
// Listing 42 aus Kapitel 4
// Standardkonformes Anzeigen eines Typs

template <typename Container>
void print_out( const Cntainer &c )
{
	typename Container::const_iterator it = c.begin();
	while( it != c.end() )
	{
		std::cout << *it << std::endl;
		++it;
	}
}
