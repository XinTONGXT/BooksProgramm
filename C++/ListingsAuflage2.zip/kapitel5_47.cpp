////////////////////////////////////////////////////////////
// Listing 47 aus Kapitel 5
// Eigene Implementierung eines Algorithmus

template<typename I, typename P>
void my_for_each( I b, I e, P p )
{
	for( I i = b; i != e; ++i )
		p( *i );
}
