////////////////////////////////////////////////////////////
// Listing 33 aus Kapitel 3
// Ein Template f�r Assertions

template <class E, class A>
inline void Assert( A assertion )
{
	if( !assertion ) throw E();
}
