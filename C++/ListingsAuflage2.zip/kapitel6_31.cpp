////////////////////////////////////////////////////////////
// Listing 31 aus Kapitel 6
// Explizite statische Deklaration von new- und delete-Operatoren

class X
{
public:
  static void* operator new( size_t );
  static void operator delete( void * );
};
