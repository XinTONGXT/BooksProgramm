////////////////////////////////////////////////////////////
// Listing 15 aus Kapitel 4
// Anwendung der Template-Methoden

// ..
Array<int, 3> a1;

a1[0] = 4;
a1[1] = 9;
a1[2] = 2;

std::cout << a1.min() << std::endl;
std::cout << a1.max() << std::endl;
// ...
