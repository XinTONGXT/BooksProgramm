////////////////////////////////////////////////////////////
// Listing 22 aus Kapitel 2
// Zeigerinkrementierung auf einem Array

	short buffer[100];
	int i;
	short *p;
	// ...
	p = buffer;
	for( i = 0; i < 100; ++i )
		*(p++) = 0;
