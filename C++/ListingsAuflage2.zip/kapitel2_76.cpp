////////////////////////////////////////////////////////////
// Listing 76 aus Kapitel 2
// Initialisierung eines konstanten Attributs

class Bitmap
{
public:
	Bitmap( unsigned long g ) : kachelgroesse(g) {}

	unsigned long kachelGroesse() const
	{ return kachelgroesse; }
private:
	const unsigned long kachelgroesse;
};
