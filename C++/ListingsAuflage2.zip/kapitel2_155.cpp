////////////////////////////////////////////////////////////
// Listing 155 aus Kapitel 2
// �berladener Pfeiloperator

class FunctionalProxy
{
public:
	// ...
	Something* operator->();
private:
	Something *element;
};

Something* FunctionalProxy::operator->()
{
	// ...
	return element;
}
