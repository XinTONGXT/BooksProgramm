/////////////////////////////////////////////////////////////////////////////////
// Listing 36 aus Kapitel 6
// Schema des globalen new-Operators aus Effektiv C++ programmieren von S. Meyers

void* operator new(size_t size)
{
	// Eine 0-Byte Anforderung wird als 
	// 1-Byte Anforderung behandelt.
	// Nach dem Standard ist eine Anforderung
	// von 0 Byte g�ltig.
	if( size == 0 ) size = 1; 

	for(;;)
	{
		Versuch, Speicher zu allokieren;
		if( Versuch erfolgreich )
			return (Zeiger auf Speicher);

		// Die Allokation ist fehlgeschlagen.
		// Jetzt muss die Fehlerbehandlungsfunktion
		// ermittelt werden.
		new_handler globalHandler = set_new_handler(0);
		set_new_handler( globalHandler );

		if( globalHandler ) (*globalHandler)();
		else throw std::bad_alloc();
	}
}
