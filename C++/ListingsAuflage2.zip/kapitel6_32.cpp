////////////////////////////////////////////////////////////
// Listing 32 aus Kapitel 6
// Deklarationspaare von new- und delete-Operatoren

class X
{
public:
  static void* operator new( size_t );
  static void* operator new[]( size_t );
  static void operator delete( void * );
  static void operator delete[]( void * );
};
