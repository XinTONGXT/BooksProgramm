////////////////////////////////////////////////////////////
// Listing 137 aus Kapitel 2
// Initialisierung einer virtuellen Basisklasse

class A
{
public:
    A( int ) {}
};
class B : virtual public A
{
public:
    B() : A( 42 ) {}
};

class C : public B
{
public:
    // Der Konstruktor von A muss in der
    // Initialisierungsliste neu aufgerufen werden
    // obwohl er schon in der Initialisierung der
    // Klasse B aufgef�hrt wurde. Durch die virtuelle
    // Vererbung von A muss die Initialisierung
    // von A in jeder Kindklassengeneration neu
    // definiert werden!
    C() : A( 42 ) {}
};

int main()
{
    C c;

    return 0;
}
