////////////////////////////////////////////////////////////
// Listing 56 aus Kapitel 4
// Implementierung des Smart Pointers

template <typename T>
class SmartPointer
{
public:
  SmartPointer( T *const ptr )
  : pObj(ptr), rc( (ptr!=0) ? new RefCounter() : 0 )
  { if(rc) rc->Inc(); }
  ~SmartPointer()
  {
    if(pObj)
    {
      rc->Dec();
      if( rc->IsZero() )
      {
        delete rc;
        delete pObj;
      }
    }
  }

  // Kopieren und zuweisen sichern
  SmartPointer(const SmartPointer &sp);
  const SmartPointer& operator=(const SmartPointer &sp);
  const SmartPointer& operator=(T *const ptr);

	// ...

private:
	T *pObj;
	RefCounter *rc;
};

template <typename T>
SmartPointer<T>::SmartPointer(const SmartPointer<T> &sp)
: rc(sp.rc)
, pObj(sp.pObj)
{
	if( rc != 0 )
		rc->Inc();
}

template <typename T>
const SmartPointer<T>&
SmartPointer<T>::operator=(const SmartPointer<T> &sp)
{
    if( pObj == sp.pObj ) return *this;

    if( pObj )
    {
      rc->Dec();
      if( rc->IsZero() )
      {
        delete rc;
        delete pObj;
      }
    }

    rc = sp.rc;
    pObj = sp.pObj;

	if( rc != 0 )
		rc->Inc();

    return sp;
}

template <typename T>
const SmartPointer<T>&
SmartPointer<T>::operator=(T *const p)
{
    if( p == pObj ) return *this;

    if( pObj )
    {
      rc->Dec();
      if( rc->IsZero() )
      {
        delete rc;
        delete pObj;
      }
    }

	rc = 0;
	if( p != 0 )
	{
		rc = new RefCounter();
		rc->Inc();
	}
	pObj = p;
	return *this;
}
