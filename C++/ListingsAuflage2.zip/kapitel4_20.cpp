////////////////////////////////////////////////////////////
// Listing 20 aus Kapitel 4
// Allgemeines Template

template <typename T, unsigned n>
class Array
{
public:
    enum { size = n };
    T& operator[]( int i ) { return data[i]; }
    const T& max() const;
    const T& min() const;
private:
    T data[n];
};
