////////////////////////////////////////////////////////////
// Listing 17 aus Kapitel 6
// Programm im AT&T-Stil

#include <iostream.h>

// ...

int main()
{
	cout << "Eine Applikation im AT&T-Stil" << endl;
	// ...
	return 0;
}
