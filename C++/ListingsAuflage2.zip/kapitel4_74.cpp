////////////////////////////////////////////////////////////
// Listing 74 aus Kapitel 4
// Die Template-Parameter des Strings in der Standard-Library

template < class E,
           class T = char_traits<E>,
           class A = allocator<E> >
class basic_string;

//...

typedef basic_string<char> string;
