////////////////////////////////////////////////////////////
// Listing 24 aus Kapitel 2
// Zugriff auf ein Array mittels Zeigerarithmetik

	short buffer[100];
	int i;
	// ...
	for( i = 0; i < 100; ++i )
		*(buffer + i) = 0;
