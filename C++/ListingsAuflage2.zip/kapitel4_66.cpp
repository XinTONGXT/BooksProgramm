////////////////////////////////////////////////////////////
// Listing 66 aus Kapitel 4
// Implementierungs-Templates

// VectorImpl.h
#include "Vector.h"

template <typename T>
Vector<T>::Vector( int c, int d )
: capacity(c), delta(d), size(0)
{
	if( this->delta <= 0 ) this->delta = 1;
	this->buf = new T[c];
}

template <typename T>
void Vector<T>::add( const T& t )
{
	if( this->size == this->capacity )
	{
		int newcapacity = this->capacity + this->delta;
		T* newbuf = new T[newcapacity];
		for( int i = 0; i < this->capacity; i++ )
			newbuf[i] = this->buf[i];
		delete [] this->buf;
		this->buf = newbuf;
		this->capacity = newcapacity;
	}
	this->buf[this->size++] = t;
}
