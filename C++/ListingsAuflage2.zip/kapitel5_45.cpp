////////////////////////////////////////////////////////////
// Listing 45 aus Kapitel 5
// Der Algorithmus copy

// ...
int main()
{
    using namespace std;

    list<int> l;
    vector<int> v;

    l.push_back( 7 );
    l.push_back( 4 );
    l.push_back( 7 );

    v.resize( l.size() );

    copy( l.begin(), l.end(), v.begin() );
    for_each( v.begin(), v.end(), ausgabe(cout) );

    return 0;
}
