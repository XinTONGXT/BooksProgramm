////////////////////////////////////////////////////////////
// Listing 8 aus Kapitel 6
// Erweiterbarkeit von Namensr�umen

namespace mylib
{
	class A
	{
	public:
		void f();
	};
}

	// ...

namespace myLib
{
	void A::f()
	{
	}
}
