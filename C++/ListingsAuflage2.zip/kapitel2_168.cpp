////////////////////////////////////////////////////////////
// Listing 168 aus Kapitel 2
// Eine einfache Dateiklasse

class Datei
{
public:
	Datei();
	~Datei();
	// ...
private:
	FILE f;
	Datei( const Datei& );
};

Datei::Datei()
{
	f = fopen( "daten.txt", "wt" );
}

Datei::~Datei()
{
	fclose( f );
}
