////////////////////////////////////////////////////////////
// Listing 86 aus Kapitel 2
// Privater Copy-Konstruktor

class Datei
{
public:
	Datei( char *name )
	{
		f = std::fopen( name, "wt" );
	}
	~Datei() { if( f ) fclose( f ); }

	void schreibe( char *txt )
	{
		if( f )
			fprintf( f, txt );
	}
private:
	std::FILE *f;
	
	// in privater Sektion verstecken!
	Datei( const Datei & );
};
