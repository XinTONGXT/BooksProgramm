////////////////////////////////////////////////////////////
// Listing 42 aus Kapitel 6
// Beispielklasse X mit �berladenen new- und delete-Operatoren

// Datei: X.h
class X
{
public:
	X() {}
	~X() {}

	static void *operator new( std::size_t );
	static void operator delete( void * );
};

// Datei: X.cpp
// Hier kann die Poolgr��e variiert werden.
ObjPool<X,300> xpool;

void *X::operator new (std::size_t s)
{
	void *p;
	// Es kann sich um einen abgeleiteten Typ handeln.
	if( s != sizeof(X) )
		p = ::operator new(s);
	else
	{
		p = xpool.getMemForObj();
		if( !p ) // Wenn der Pool schon voll ist.
			p = ::operator new( s );
	}
	return reinterpret_cast<X*>(p);
}

void X::operator delete( void *p )
{
	if( xpool.isIn(p) )
		xpool.freeMemOfObj(p);
	else
		::operator delete( p );
}
