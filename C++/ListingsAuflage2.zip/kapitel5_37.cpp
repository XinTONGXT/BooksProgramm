////////////////////////////////////////////////////////////
// Listing 37 aus Kapitel 5
// Standardkonforme Deklaration eines Pr�dikat-Templates

template <typename T>
class compare
: public std::binary_function<T,T,bool>
{
public:
    bool operator()( const T &v1, const T &v2 ) const
    {
        return v1 == v2;
    }
};
