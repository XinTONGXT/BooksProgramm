////////////////////////////////////////////////////////////
// Listing 152 aus Kapitel 2
// �berladung des Zuweisungsoperators

class Complex
{
public:
	double i;
	double r;

	Complex& operator=( const Complex &c );
};

Complex& Complex::operator=( const Complex &c )
{
	i = c.i;
	r = c.r;
	return *this;
}
