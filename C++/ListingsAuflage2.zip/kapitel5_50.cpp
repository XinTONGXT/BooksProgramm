////////////////////////////////////////////////////////////
// Listing 50 aus Kapitel 5
// Anwendung von string::npos

#include <iostream>
#include <string>

int main()
{
    using namespace std;

    char *p = "Schnapsflasche";
    string str1( "Polyamid" );
    string str2( p, 7 );
    string str3( str1, 6, string::npos );
    string str4( 2, 'e' );

    cout << (str2 + str3 + str4) << endl;

    return 0;
}
