////////////////////////////////////////////////////////////
// Listing 30 aus Kapitel 3
// Invariantenpr�fung durch entfernbaren Code

void Vektor::AddEnd( ELEMENT e )
{
#ifdef __DEBUG__
	if( capacity < 1 || size > capacity || buf == 0 )
		throw SomeException();
#endif
	
	if( size == capacity )
  	Grow();
  buf[size++] = e;

#ifdef __DEBUG__
  if( capacity < 1 || size > capacity || buf == 0 )
		throw SomeException();
#endif
}
