////////////////////////////////////////////////////////////
// Listing 4 aus Kapitel 2
// Die Anwendung des Pr�prozessoroperators defined

#if defined(BIGENDIAN)
// ...
