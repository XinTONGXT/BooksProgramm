////////////////////////////////////////////////////////////
// Listing 119 aus Kapitel 2
// Methodenaufruf

// Pseudocode
void Ausgabefenster::zeichne( Grafikelement *e )
{
	e->zeichne( liefereZeichenflaeche() );
}
