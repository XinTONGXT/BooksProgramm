////////////////////////////////////////////////////////////
// Listing 34 aus Kapitel 5
// Funktorimplementierung des Pr�dikats

// ...
class test
{
public:
	bool operator()( int i )
	{
		return (i % 2) == 0;
	}
};

int main()
{
	// ...
	int n = count_if( l.begin(), l.end(), test() );
	// ...
}
