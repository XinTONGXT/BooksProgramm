////////////////////////////////////////////////////////////
// Listing 30 aus Kapitel 6
// �berladener delete-Operator

class X
{
public:
  void operator delete( void * );
  // ...
};
