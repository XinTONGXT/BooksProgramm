////////////////////////////////////////////////////////////
// Listing 14 aus Kapitel 3
// Die Attribute der Liste

class Liste
{
public:
	Liste() : anfang(0), ende(0) {}
private:
	Knoten *anfang, *ende;
};
