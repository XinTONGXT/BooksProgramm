////////////////////////////////////////////////////////////
// Listing 10 aus Kapitel 4
// Ein Klassentemplate

template <typename T, unsigned n>
class Array
{
public:
    enum { size = n };
    T& operator[]( int i ) { return data[i]; }
private:
    T data[n];
};
