////////////////////////////////////////////////////////////
// Listing 25 aus Kapitel 6
// Das Template min()

// Headerdatei MIN.H
template <class T>
const T& min( const T& t1, const T& t2 )
{
	return ( t1 < t2 ) ? t1 : t2;
}
