////////////////////////////////////////////////////////////
// Listing 11 aus Kapitel 6
// Anwendung der using-Direktive auf ein Einzelelement

#include <string>
	
void f()
{
	using std::string;

	string s = "Text";

	// ...
}
