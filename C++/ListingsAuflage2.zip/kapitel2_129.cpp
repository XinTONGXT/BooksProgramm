////////////////////////////////////////////////////////////
// Listing 129 aus Kapitel 2
// Dynamischer Downcast

#include <iostream>

class X
{
public:
    virtual ~X() {}
};

class A : public X {};
class B : public X {};

void f( X* p )
{
	using namespace std;
  A* ap = dynamic_cast<A*>(p);
  if( ap )
    cout << "p zeigt auf ein Objekt von A" << endl;
  else
    cout << "p zeigt auf kein Objekt von A" << endl;
}

int main()
{
    A a;
    B b;

    f( &a );
    f( &b );

    return 0;
}
