////////////////////////////////////////////////////////////
// Listing 1 aus Kapitel 3
// Implementierung des Ampelbeispiels

#include <iostream>
using namespace std;

typedef char EVENT;

class Phase
{
public:
	virtual ~Phase();

	virtual void enterState() = 0;
	virtual void exitState() = 0;
	virtual void handleEvent( EVENT ) = 0;

	Phase *folgezustand;
};

class Rot : public Phase
{
public:
	void enterState();
	void exitState();
	void handleEvent( EVENT );
};

class Gelb : public Phase
{
public:
	void enterState();
	void exitState();
	void handleEvent( EVENT );
};

class Gruen : public Phase
{
public:
	void enterState();
	void exitState();
	void handleEvent( EVENT );
};

class RotGelb : public Phase
{
public:
	void enterState();
	void exitState();
	void handleEvent( EVENT );
};

class Betriebszustand
{
public:
	virtual ~Betriebszustand();

	virtual void enterState() = 0;
	virtual void exitState() = 0;
	virtual void handleEvent( EVENT ) = 0;

	Betriebszustand *folgezustand;
};

class InBetrieb : public Betriebszustand
{
public:
	InBetrieb();
	void enterState();
	void exitState();
	void handleEvent( EVENT );

private:
	Rot rot;
	Gelb gelb;
	RotGelb rotgelb;
	Gruen gruen;
	Phase *aktuellerzustand;
};

class Blinkend : public Betriebszustand
{
public:
	void enterState();
	void exitState();
	void handleEvent( EVENT );
};

class Ampel
{
public:
	Ampel();

	bool handleEvent( EVENT e );

private:
	InBetrieb inbetrieb;
	Blinkend blinkend;
	Betriebszustand *aktuellerzustand;
};

///////////////////////////////////////

Ampel::Ampel()
{
	inbetrieb.folgezustand = &blinkend;
	blinkend.folgezustand = &inbetrieb;
	aktuellerzustand = &inbetrieb;
}

bool Ampel::handleEvent( EVENT e )
{
	bool ret = true;
	switch( toupper( e ) )
	{
	case 'B':
		aktuellerzustand->exitState();
		aktuellerzustand = aktuellerzustand->folgezustand;
		aktuellerzustand->enterState();
		break;
	case 'X':
		ret = false;
	default:
		aktuellerzustand->handleEvent( e );
	}
	return ret;
}

Phase::~Phase() {}

void Rot::enterState() { cout << "ROT" << endl; }
void Rot::exitState() {}
void Rot::handleEvent( EVENT ) {}

void RotGelb::enterState()
{ cout << "ROT-GELB" << endl; }
void RotGelb::exitState() {}
void RotGelb::handleEvent( EVENT ) {}

void Gelb::enterState() { cout << "GELB" << endl; }
void Gelb::exitState() {}
void Gelb::handleEvent( EVENT ) {}

void Gruen::enterState() { cout << "GRUEN" << endl; }
void Gruen::exitState() {}
void Gruen::handleEvent( EVENT ) {}

Betriebszustand::~Betriebszustand() {}

InBetrieb::InBetrieb()
{
	rot.folgezustand = &rotgelb;
	rotgelb.folgezustand = &gruen;
	gruen.folgezustand = &gelb;
	gelb.folgezustand = &rot;
	aktuellerzustand = &rot;
}
void InBetrieb::enterState()
{
	aktuellerzustand = &rot;
	aktuellerzustand->enterState();
}
void InBetrieb::exitState()
{
	aktuellerzustand->exitState();
}
void InBetrieb::handleEvent( EVENT e )
{
	switch( toupper( e ) )
	{
	case 'F':
		aktuellerzustand->exitState();
		aktuellerzustand = aktuellerzustand->folgezustand;
		aktuellerzustand->enterState();
		break;
	default:
		aktuellerzustand->handleEvent( e );
	}
}

void Blinkend::enterState()
{ cout << "blinkend" << endl; }
void Blinkend::exitState() {}
void Blinkend::handleEvent( EVENT ) {}

int main()
{
	Ampel ampel;

	EVENT e;
	do
	{
		cin >> e;
	} while( ampel.handleEvent( e ) );

	return 0;
}
