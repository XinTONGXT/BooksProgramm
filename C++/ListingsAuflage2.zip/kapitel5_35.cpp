////////////////////////////////////////////////////////////
// Listing 35 aus Kapitel 5
// Adaptieren von Pr�dikaten

#include <iostream>
#include <list>
#include <algorithm>

class compare
{
public:
    typedef int first_argument_type;
    typedef int second_argument_type;
    typedef bool result_type;
    bool operator()( int i, int v ) const
    {
        return i == v;
    }
};

int main()
{
    using namespace std;

    list<int> l;

    l.push_back( 3 );
    l.push_back( 4 );
    l.push_back( 3 );
    l.push_back( 1 );

    int n = std::count_if( l.begin(),
                           l.end(),
                           bind2nd(compare(),3) );
    cout << n << endl;

    return 0;
}
