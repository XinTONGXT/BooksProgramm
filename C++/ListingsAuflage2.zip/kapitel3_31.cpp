////////////////////////////////////////////////////////////
// Listing 31 aus Kapitel 3
// Invariantenpr�fung mit dem Makro assert()

void Vektor::AddEnd( ELEMENT e )
{
	assert(capacity < 1 || size > capacity || buf == 0);

	if( size == capacity )
		Grow();
	buf[size++] = e;

	assert(capacity < 1 || size > capacity || buf == 0);
}
