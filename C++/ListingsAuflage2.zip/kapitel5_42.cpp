////////////////////////////////////////////////////////////
// Listing 42 aus Kapitel 5
// Anwendung von transform auf einen C-String

// ...
using namespace std;
string str = "Ein Text";
transform( str.begin(), str.end(),
           str.begin(), toupper );
