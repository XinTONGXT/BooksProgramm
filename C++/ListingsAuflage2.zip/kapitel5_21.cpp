////////////////////////////////////////////////////////////
// Listing 21 aus Kapitel 5
// Ein Demonstrationsbeispiel zum STL-Set

#include <iostream>
#include <set>

int main()
{
    using namespace std;

    set<int> s;

    s.insert( 3 );
    s.insert( 4 );
    s.insert( 1 );
    s.insert( 2 );

    for( set<int>::iterator it = s.begin();
         it != s.end(); ++it )
        cout << *it << endl;

    return 0;
}
