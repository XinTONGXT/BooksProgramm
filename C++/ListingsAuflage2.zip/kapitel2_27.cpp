////////////////////////////////////////////////////////////
// Listing 27 aus Kapitel 2
// Explizite Typenkonvertierung

	long i;
	short s;
	// ...
	i = 42;
	/* Typenkonvertierung */
	s = (short)i;
