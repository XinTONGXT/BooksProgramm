////////////////////////////////////////////////////////////
// Listing 52 aus Kapitel 4
// Die Anwendung der Liste

#include <iostream>
#include "Liste.h"

int main()
{
	Liste<int> liste;

	liste.AddEnd( 3 );
	liste.AddEnd( 5 );
	liste.AddEnd( 7 );

	for( Liste<int>::Zugriff z = liste.Begin();
	     z.IsValid(); z.Inc() )
	{
		std::cout << z.get() << std::endl;
	}

	return 0;
}
