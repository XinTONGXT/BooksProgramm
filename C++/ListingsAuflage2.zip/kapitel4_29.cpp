////////////////////////////////////////////////////////////
// Listing 29 aus Kapitel 4
// �berschriebene Methode

include <iostream>
class A
{
public:
	void f() { std::cout << "A::f()" << std::endl; }
};

class B : public A
{
public:
	void f() { std::cout << "B::f()" << std::endl; }
};

int main()
{
	B b;
	b.f();

	return 0;
}
