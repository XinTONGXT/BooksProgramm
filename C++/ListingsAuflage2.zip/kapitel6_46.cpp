////////////////////////////////////////////////////////////
// Listing 46 aus Kapitel 6
// Testcode f�r die Ringindex-Klasse

#include <iostream>

int main()
{	using namespace std;

	int array[3];
	RingIndex r(3);
	
	array[r++] = 701;
	array[r++] = 702;
	array[r++] = 703;
	
	cout << array[r++] << endl;
	cout << array[r++] << endl;
	cout << array[r++] << endl;
	cout << array[r++] << endl;
	cout << array[r++] << endl;
	cout << array[r]   << endl;

	return 0;
}
