////////////////////////////////////////////////////////////
// Listing 33 aus Kapitel 6
// Demo zur �berladung von new und delete

#include <cstddef>
#include <new>
#include <iostream>

class X
{
public:
	static void* operator new ( std::size_t s );
	static void  operator delete ( void *, std::size_t );
};

class Y : public X
{
	public:
	char array[1000];
};

void* X::operator new ( std::size_t s )
{
	std::cout << s
	          << " Bytes durch new angefordert."
	          << std::endl;
	return ::operator new (s);
}

void  X::operator delete ( void *p, std::size_t s )
{
	::operator delete( p );	
	std::cout << s
	          << " Bytes durch delete feigegeben."
	          << std::endl;
}

int main()
{
	X *p1 = new X();
	Y *p2 = new Y();

	delete p1;
	delete p2;

	return 0;
}
