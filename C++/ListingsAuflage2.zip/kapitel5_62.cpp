////////////////////////////////////////////////////////////
// Listing 62 aus Kapitel 5
// L�sen des Objekts aus der Verantwortung des Autopointers

// ...
int main()
{
    std::auto_ptr<X> p( new X() );

    X *xp = p.release();

    delete xp;

    return 0;
}
