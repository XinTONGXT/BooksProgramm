////////////////////////////////////////////////////////////
// Listing 1 aus Kapitel 6
// Sicherung gegen Mehrfachinklusion

// Die Datei container.h
#ifndef __CONTAINER_H
#define __CONTAINER_H

class Liste
{
	// ...
};

class Vektor
{
	// ...
};
#endif // __CONTAINER_H
