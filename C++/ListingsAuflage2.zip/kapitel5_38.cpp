////////////////////////////////////////////////////////////
// Listing 38 aus Kapitel 5
// Ein in der STL vordefiniertes Pr�dikat

// ...
int main()
{
    // ...
    int n = count_if( l.begin(), l.end(),
                      bind2nd(equal_to<int>(),3) );
    cout << n << endl;

    return 0;
}
