////////////////////////////////////////////////////////////
// Listing 28 aus Kapitel 2
// Dynamische Speicherallokation mit Hilfe von Zeigern

	void *p;
	int *ip;
	/* Speicheranforderung... */
	p = malloc( 100 * sizeof(int) );
	ip = (int *)p;
	/* ... */
