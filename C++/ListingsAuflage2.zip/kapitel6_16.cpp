////////////////////////////////////////////////////////////
// Listing 16 aus Kapitel 6
// Erweiterung des Namens bei Elementdefinition

namespace myPrj
{
	class A
	{
	public:
		void f();
	};
}

// ...

void myPrj::A::f()
{
	// ...
}
