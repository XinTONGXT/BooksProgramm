////////////////////////////////////////////////////////////
// Listing 57 aus Kapitel 5
// Mengenoperationen auf Valarrays

#include <iostream>
#include <valarray>

void print_out( const std::valarray<int> &va )
{
    for( unsigned i = 0; i < va.size(); ++i )
        std::cout << va[i] << " ";
    std::cout << std::endl;
}

int loesche_gerade_zahlen( int i )
{
    return ( i % 2 ) ? i : 0;
}

int main()
{
		using namespace std;
    int a[] = { 5, 4, 1, 2 };
    valarray<int> v1(a,4);

    print_out( v1 );

    valarray<int> v2 = v1.apply(loesche_gerade_zahlen);

    print_out( v2 );

    return 0;
}
