////////////////////////////////////////////////////////////
// Listing 146 aus Kapitel 2
// Verkettung der �berladenen Streamoperatoren

...
Complex z1 = {3,5};
Complex z2 = {2,1};

Complex z3 = z1 + z2;

std::cout << z1 << "+" << z2 << "=" << z3 << std::endl;
...
