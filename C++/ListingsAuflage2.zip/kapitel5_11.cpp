////////////////////////////////////////////////////////////
// Listing 11 aus Kapitel 5
// Feldbreite und Leerraumformatierung mit Manipulatoren

// ...
cout << setw(7) << setfill('-') << (i*i*i) << endl;
// ...
