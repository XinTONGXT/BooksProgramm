////////////////////////////////////////////////////////////
// Listing 1 aus Kapitel 5
// Einfache Anwendung von C++-Streams

#include <iostream>
#include <fstream>

int main()
{
	std::cout << "Ein Text" << std::endl;

	std::ofstream datei( "test.txt" );
	datei << "Ein Text" << std::endl;

	return 0;
}
