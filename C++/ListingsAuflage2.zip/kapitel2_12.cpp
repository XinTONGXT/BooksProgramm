////////////////////////////////////////////////////////////
// Listing 12 aus Kapitel 2
// Syntax des enum-Typs

enum STATUS { AUS, AN };
// ...
STATUS status = AN;
// ...
switch(status)
{
	case AN:
		// ...
		break;
	case AUS:
		// ...
		break;
}
