////////////////////////////////////////////////////////////
// Listing 110 aus Kapitel 2
// Instanzz�hlung mit statischen Elementen

class X
{
public:
	X() { neueInstanz(); }
	X( const X & ) { neueInstanz(); }
	static unsigned long anzahlInstanzen();
private:
	static void neueInstanz();
	static unsigned long instanzen;
};

// ...

unsigned long X::instanzen = 0;

void X::neueInstanz()
{
	instanzen++;
}

unsigned long X::anzahlInstanzen()
{
	return instanzen;
}
