////////////////////////////////////////////////////////////
// Listing 40 aus Kapitel 2
// �berladene Funktion minimum()

// ...

// Prototypen
int minimum( int, int );           // Variante 1
double minimum( double, double );  // V. 2
int minimum( int, int, int );      // V. 3
int minimum( int, int, int, int ); // V. 4

void f()
{
	int a = 1, b = 2, c = 3, d = 4;
	double x = 2.7, y = 7.3;

	std::cout << minimum( d, b ) << std::endl;
	std::cout << minimum( a, b, c, d ) << std::endl;
	std::cout << minimum( x, y ) << std::endl;
	std::cout << minimum( c, x ) << std::endl; // V. 2 !
	
	// ...
}
