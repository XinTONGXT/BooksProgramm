////////////////////////////////////////////////////////////
// Listing 151 aus Kapitel 2
// �berladung des Multiplikationsoperators

Complex Complex::operator*( const Complex &c ) const
{
    Complex result = { r*c.r - i*c.i, i*c.r + r*c.i };
    return result;
}
