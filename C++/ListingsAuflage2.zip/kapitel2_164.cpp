////////////////////////////////////////////////////////////
// Listing 164 aus Kapitel 2
// Weiterreichen einer teilbehandelten Ausnahme

// ...
catch( Ausnahme1 &e1 )
{
	cout << "Die Ausnahme 1 ist aufgetreten!" << endl;
	throw e1;
}
// ...
