////////////////////////////////////////////////////////////
// Listing 87 aus Kapitel 2
// Implizite Typenkonvertierung mit dem Konstruktor

#include <iostream>

class Punkt
{
public:
	Punkt( int vx, int vy ) : x(vx), y(vy) {}
	Punkt( const class Vektor &v );

	int x;
	int y;
};

class Vektor
{
public:
	Vektor( int vx, int vy ) : dx(vx), dy(vy) {}

	int dx;
	int dy;
};

Punkt::Punkt( const Vektor &v ) : x(v.dx), y(v.dy) {}

int main()
{
	Vektor v( 3, 4 );
	Punkt p( 0, 0 );

	p = v; // implizite Typenkonvertierung!

	return 0;
}
