////////////////////////////////////////////////////////////
// Listing 74 aus Kapitel 2
// Initialisierung von Basisklassenelementen

class Form
{
public:
	Form( unsigned int farbe ) : farbwert(farbe) {}
protected:
	unsigned int farbwert;
};

class Kreis : public Form
{
public:
	Kreis( const Punkt &vm,
	       double vr,
	       unsigned int farbe )
	: Form(farbe), m(vm.x,vm.y), r(vr) {}

private:
	Punkt m;
	double r;
};
