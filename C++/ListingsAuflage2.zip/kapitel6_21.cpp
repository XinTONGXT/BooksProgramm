////////////////////////////////////////////////////////////
// Listing 21 aus Kapitel 6
// Schritt 1: Ein sehr einfaches Programm

#include <iostream>
#include <string>
	
int main()
{
	std::string str = "Na sowas!";

	std::cout << str;

	return 0;
}
