////////////////////////////////////////////////////////////
// Listing 149 aus Kapitel 2
// Kopie des R�ckgabewertes

Complex Complex::operator+( const Complex &c ) const
{
    Complex result = { r + c.r, i + c.i };
    return result;
}
