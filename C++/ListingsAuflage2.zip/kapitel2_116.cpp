////////////////////////////////////////////////////////////
// Listing 116 aus Kapitel 2
// Elementsichtbarkeit bei gesch�tzter Vererbung

class Basis
{
public:
	int b1;
protected:
	int b2;
private:
	int b3;
};

class S3 : protected Basis
{
public:
	void f();
};

void S3::f()
{
	b1 = 0; // OK
	b2 = 0; // OK
	b3 = 0; // Nicht erlaubt! Compilefehler.
}

int main()
{
	S3 obj;
	obj.b1 = 0; // Nicht erlaubt! Compilefehler.
	obj.b2 = 0; // Nicht erlaubt! Compilefehler.
	obj.b3 = 0; // Nicht erlaubt! Compilefehler.

	return 0;
}
