////////////////////////////////////////////////////////////
// Listing 22 aus Kapitel 3
// Die Implementierung der Methode AddEnd() f�r polymorphe Listen-elemente

void Liste::AddEnd( Listenelement *e )
{
	Knoten *k = new Knoten( e );
	if( ende )
	{
		ende->next = k;
		k->prev = ende;
		ende = k;
	}
	else
	{
		anfang = ende = k;
	}
}
