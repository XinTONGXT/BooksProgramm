////////////////////////////////////////////////////////////
// Listing 85 aus Kapitel 2
// Typischer Fehler im Zusammenhang mit dem Copy-Konstruktor

#include <cstdio>

class Datei
{
public:
	Datei( char *name )
	{
		f = std::fopen( name, "wt" );
	}
	~Datei() { if( f ) fclose( f ); }

	void schreibe( char *txt )
	{
		if( f )
			fprintf( f, txt );
	}
private:
	std::FILE *f;
};

// ...

void f( Datei d )
{
	d.schreibe( "Eine Zeile Text.\n" );
}

int main()
{
	Datei d( "test.txt" );

	f( d );
	d.schreibe( "Und noch eine Zeile\n" );

	return 0;
}
