////////////////////////////////////////////////////////////
// Listing 47 aus Kapitel 2
// Dynamische Speicherallokation in C++ mit new und delete

long *p = NULL;
try
{
	p = new long[1000];
}
catch( std::bad_alloc &e )
{
}

...
delete [] p;
