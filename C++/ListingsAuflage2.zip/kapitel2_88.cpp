////////////////////////////////////////////////////////////
// Listing 88 aus Kapitel 2
// explicit-Deklaration eines Konstruktors

class Punkt
{
public:
	// ...
	explicit Punkt( const class Vektor &v );
	// ...
};
