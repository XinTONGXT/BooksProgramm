////////////////////////////////////////////////////////////
// Listing 47 aus Kapitel 6
// RingIndex-Objekt mit der Speicherklasse volatile

...
int array[3];
volatile RingIndex r(3);
	
array[r++] = 701; // Fehler, Operator ++ undefiniert!
...
