////////////////////////////////////////////////////////////
// Listing 7 aus Kapitel 5
// Formatierung einer Ausgabe auf ein ostream-Objekt �ber Flags

#include <iostream>

int main()
{
	using namespace std;
	int i = 42;

	ios_base::fmtflags old = cout.flags(ios_base::oct);
	cout << i << endl;
	cout.flags(ios_base::hex);
	cout << i << endl;
	cout.flags(old);
	cout << i << endl;

	return 0;
}
