////////////////////////////////////////////////////////////
// Listing 130 aus Kapitel 2
// Dynamischer Sidecast

#include <iostream>

class X
{
public:
    virtual ~X() {}
};

class Y
{
public:
    virtual ~Y() {}
};

class A : public X {};
class B : public X, public Y {};

void f( X* p )
{
  using namespace std;
  Y* yp = dynamic_cast<Y*>(p);
  if( yp )
    cout << "Konverierung nach Y* erfolgreich." << endl;
}

int main()
{
    A a;
    B b;
    f( &a );
    f( &b );

    return 0;
}
