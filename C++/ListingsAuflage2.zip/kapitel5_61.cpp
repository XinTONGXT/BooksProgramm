////////////////////////////////////////////////////////////
// Listing 61 aus Kapitel 5
// Automatische Freigabe des dynamisch instanziierten Objekts

#include <iostream>
#include <memory>

class X
{
public:
    X()  { std::cout << "X::X()"  << std::endl; }
    ~X() { std::cout << "X::~X()" << std::endl; }
};

int main()
{
    std::auto_ptr<X> p( new X() );

    return 0;
}
