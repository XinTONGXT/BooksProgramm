////////////////////////////////////////////////////////////
// Listing 61 aus Kapitel 2
// Methoden

class Kreis
{
public:
	double Umfang();
	double Flaeche();

	int x, y;
	double r;
};
