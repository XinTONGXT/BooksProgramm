////////////////////////////////////////////////////////////
// Listing 96 aus Kapitel 2
// Schleife ohne Einfluss auf die Schleifenbedingung

while( !a )
{
	Sleep( 1 ); // 1 Millisekunde
	ticks++;
}
