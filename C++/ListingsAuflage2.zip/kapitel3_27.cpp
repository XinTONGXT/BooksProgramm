////////////////////////////////////////////////////////////
// Listing 27 aus Kapitel 3
// Typenkonvertierungsoperator f�r G�ltigkeitspr�fung

operator bool() { return k != 0; }
