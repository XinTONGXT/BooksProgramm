////////////////////////////////////////////////////////////
// Listing 67 aus Kapitel 2
// Standardm��ige private Vererbung

class A
{
public:
	int x;
};

class B : A
{
};
