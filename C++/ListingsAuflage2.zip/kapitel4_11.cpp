////////////////////////////////////////////////////////////
// Listing 11 aus Kapitel 4
// Instanziierung eines Klassentemplates

// ...
Array<int, 5> a1;

for( int i = 0; i < a1.size; ++i )
	a1[i] = 0;
// ...
