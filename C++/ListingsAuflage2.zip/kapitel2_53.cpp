////////////////////////////////////////////////////////////
// Listing 53 aus Kapitel 2
// �bergabe eines Strukturzeigers an eine Funktion

void KreisInitialisierung( struct Kreis *k )
{
  k->m.x = 0;
  k->m.y = 0;
  k->r = 0;
}
