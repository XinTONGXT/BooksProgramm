////////////////////////////////////////////////////////////
// Listing 11 aus Kapitel 3
// Eine 1-zu-5-Aggregation

class A { /* ... */ };

class B
{
public:
	// ...
private:
	A* array[5];
};
