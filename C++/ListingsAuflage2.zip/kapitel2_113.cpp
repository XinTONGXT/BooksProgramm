////////////////////////////////////////////////////////////
// Listing 113 aus Kapitel 2
// Sichtbarkeit in der Vererbung

class Basis
{
// ...
};

class S1 : Basis
{
// ...
};

class S2 : public Basis
{
// ...
};

class S3 : protected Basis
{
// ...
};

class S4 : private Basis
{
// ...
};
