////////////////////////////////////////////////////////////
// Listing 12 aus Kapitel 5
// Definition eines eigenen Manipulators

#include <iostream>
#include <iomanip>

std::ostream & myfield(std::ostream &os)
{
	using namespace std;
	return os << setw(7) << setfill('-');
}

int main()
{
	using namespace std;

	cout << right;
	
	for( int i = 1; i < 7; ++i )
	{
		cout << myfield << (i*i*i) << endl;
	}

	return 0;
}
