////////////////////////////////////////////////////////////
// Listing 6 aus Kapitel 3
// Singleton mit W�chterklasse

class Singleton
{
   public:
     static Singleton* exemplar();

   private:
     static Singleton *instanz;
     Singleton() {}
     Singleton( const Singleton& );

     ~Singleton() {}

     class Waechter {
         public: ~Waechter() {
           if( Singleton::instanz != 0 )
             delete Singleton::instanz;
         }
     };
     friend class Waechter;
};

Singleton* Singleton::instanz = 0;

Singleton* Singleton::exemplar()
{
  static Waechter w;
  if( instanz == 0 )
    instanz = new Singleton();
  return instanz;
}
