////////////////////////////////////////////////////////////
// Listing 2 aus Kapitel 6
// Die Alles-�berall-Inklusion

// Header DB.h
class DBZugriff
{
	// ...
};
// Ende DB.h

// Header DBDialog.h
#include "DB.h"
class DBDialog
{
	DBZugriff *zugriff;
	// ...
};
// Ende DBDialog.h

// Applikation.cpp
#include "DBDialog.h"

int OpenDBDialog()
{
	DBDialog dlg;
	// ...
}
// Ende Applikation.cpp
