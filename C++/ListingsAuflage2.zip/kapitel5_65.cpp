////////////////////////////////////////////////////////////
// Listing 65 aus Kapitel 5
// Die Operatoren * und -> am Autopointer

#include <iostream>
#include <memory>

class X
{
public:
    X()  { std::cout << "X::X()"  << std::endl; }
    ~X() { std::cout << "X::~X()" << std::endl; }

    void f() { std::cout << "X::f()" << std::endl; }
};

int main()
{
    using namespace std;

    auto_ptr<X> p1( new X() );
    auto_ptr<int> p2( new int() );

    p1->f();

    *p2 = 42;

    cout << *p2 << endl;

    return 0;
}
