////////////////////////////////////////////////////////////
// Listing 60 aus Kapitel 5
// Eine Submatrix mit gslice

#include <iostream>
#include <valarray>

std::ostream & operator<<( std::ostream &os,
                     const std::slice_array<int> &sa )
{
    std::valarray<int> va( sa );
    for( int i = 0; i < va.size(); ++i )
        os << va[i] << "\t";
    return os;
}

int main()
{
    using namespace std;
    int a[] = { 10, 11, 12, 20, 21, 22,
                30, 31, 32, 40, 41, 42 };
    valarray<int> v(a,3*4);

    valarray<size_t> laengebreite(2);
    valarray<size_t> schritte(2);

    laengebreite[0] = 2;
    laengebreite[1] = 1;
    schritte[0] = 3;
    schritte[1] = 1;
    gslice gs(7, laengebreite, schritte );

    valarray<int> e = v[gs];

    cout << e[slice(0,2,1)] << endl;
    cout << e[slice(2,2,1)] << endl;

    return 0;
}
