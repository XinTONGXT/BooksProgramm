////////////////////////////////////////////////////////////
// Listing 163 aus Kapitel 2
// Ausnahmebehandlung anhand der Typunterscheidung

class Ausnahme1{};
class Ausnahme2{};
class Ausnahme3{};
class AusnahmeX{};

void f1()
{
// ...
	throw Ausnahme1();
// ...
}
void f2()
{
// ...
	throw Ausnahme2();
// ...
}
void f3()
{
// ...
	throw Ausnahme3();
// ...
}

int main()
{
	try
	{
		f1();
		f2();
		f3();
	}
	catch( Ausnahme1 &e1 )
	{
		cout << "Die Ausnahme 1 ist aufgetreten!" << endl;
	}
	catch( Ausnahme2 &e2 )
	{
		cout << "Die Ausnahme 2 ist aufgetreten!" << endl;
	}
	catch( Ausnahme3 &e3 )
	{
		cout << "Die Ausnahme 3 ist aufgetreten!" << endl;
	}
	catch( ... )
	{
		cout << "Eine unbekannte Ausnahme ist aufgetreten!"
		     << endl;
	}

	return 0;
}
