////////////////////////////////////////////////////////////
// Listing 2 aus Kapitel 3
// Singletonimplementierung nach cite{GoF95

class Singleton
{
   public:
     static Singleton* exemplar();

   protected:
     Singleton() {}

   private:
     static Singleton *instanz;
};

Singleton* Singleton::instanz = 0;

Singleton* Singleton::exemplar()
{
  if( instanz == 0 )
    instanz = new Singleton();
  return instanz;
}
