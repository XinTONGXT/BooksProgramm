////////////////////////////////////////////////////////////
// Listing 7 aus Kapitel 4
// Die alte Template-Syntax mit dem Schl�sselwort class

template <class T>
T min( T a, T b )
{
	return (a < b) ? a : b;
}
