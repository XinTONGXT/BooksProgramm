////////////////////////////////////////////////////////////
// Listing 54 aus Kapitel 2
// Const-Maskierung eines Strukturzeigers

double KreisUmfang( const struct Kreis *k )
{
  return 2.0 * k->r * 3.141;
}
