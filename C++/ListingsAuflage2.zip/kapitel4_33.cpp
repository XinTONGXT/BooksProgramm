////////////////////////////////////////////////////////////
// Listing 33 aus Kapitel 4
// Das rebind-Element aus der STL

template <typename T> allocator
{
	//...
	template <typename U> struct rebind
	{
		typedef allocator<U> other;
	};
	//...
};
