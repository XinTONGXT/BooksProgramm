////////////////////////////////////////////////////////////
// Listing 154 aus Kapitel 2
// Globaler Dereferenzierungsoperator

class FunctionalProxy
{
public:
	// ...
	friend Something& operator*(FunctionalProxy &);
private:
	Something *element;
};

Something& operator*(FunctionalProxy &p)
{
	// ...
	return *(p->element);
}
