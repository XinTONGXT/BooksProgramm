////////////////////////////////////////////////////////////
// Listing 41 aus Kapitel 2
// Normale Funktion

long zinsen( long betrag, double zinssatz )
{
	return (long)(betrag * zinssatz);
}
