////////////////////////////////////////////////////////////
// Listing 58 aus Kapitel 5
// Submengenbildung durch Indizierung mit slice-Objekten

#include <iostream>
#include <valarray>

std::ostream & operator<<( std::ostream &os,
                           const std::valarray<int> &va )
{
    for( int i = 0; i < va.size(); ++i )
        os << va[i] << "  ";
    return os;
}

int main()
{
    using namespace std;
    int a[] = { 10, 11, 12, 20, 21, 22,
                30, 31, 32, 40, 41, 42 };
    valarray<int> v(a,3*4);

    slice z1( 0, 3, 1 );
    slice z2( 3, 3, 1 );
    slice z3( 6, 3, 1 );
    slice z4( 9, 3, 1 );
    slice s1( 0, 4, 3 );
    slice s2( 1, 4, 3 );
    slice s3( 2, 4, 3 );

    valarray<int> zeile1 = v[z1];
    valarray<int> zeile2 = v[z2];
    valarray<int> zeile3 = v[z3];
    valarray<int> zeile4 = v[z4];

    valarray<int> spalte1 = v[s1];
    valarray<int> spalte2 = v[s2];
    valarray<int> spalte3 = v[s3];

    cout << zeile1 << endl;
    cout << zeile2 << endl;
    cout << zeile3 << endl;
    cout << zeile4 << endl;

    cout << endl;

    cout << spalte1 << endl;
    cout << spalte2 << endl;
    cout << spalte3 << endl;

    return 0;
}
