////////////////////////////////////////////////////////////
// Listing 29 aus Kapitel 3
// Implementierung einer Vektormethode mit Invariantenpr�fung

void Vektor::AddEnd( ELEMENT e )
{
	if( capacity < 1 || size > capacity || buf == 0 )
		throw SomeException();
	
	if( size == capacity )
		Grow();
	buf[size++] = e;

	if( capacity < 1 || size > capacity || buf == 0 )
		throw SomeException();
}
