////////////////////////////////////////////////////////////
// Listing 169 aus Kapitel 2
// Abbruch des Konstruktors mit einer Exception

Datei::Datei()
{
	f = fopen( "daten.txt", "wt" );
	if( f == NULL ) throw DateiFehler();
}

Datei::~Datei()
{
	fclose( f );
}
