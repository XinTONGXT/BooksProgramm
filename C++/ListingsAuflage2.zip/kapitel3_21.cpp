////////////////////////////////////////////////////////////
// Listing 21 aus Kapitel 3
// Eine Basisklasse f�r polymorphe Listenelemente

// In Liste.h
class Listenelement
{
public:
	virtual ~Listenelement();
};

// In Liste.cpp
Listenelement::~Listenelement() {}
