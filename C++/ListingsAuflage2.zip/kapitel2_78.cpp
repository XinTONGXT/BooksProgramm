////////////////////////////////////////////////////////////
// Listing 78 aus Kapitel 2
// Deklaration eines Destruktors

class Punkt
{
public:
	Punkt( int vx, int vy ); // Konstruktor
	~Punkt();                // Destruktor
	int x;
	int y;
};
