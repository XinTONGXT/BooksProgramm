////////////////////////////////////////////////////////////
// Listing 26 aus Kapitel 4
// Qualifizierung �ber den this-Zeiger

class Punkt
{
public:
	Punkt( int vx, int vy ) : x(vx), y(vy) {}
	bool operator==( const Punkt &p ) const
	{
		if( this->x == p.x && this->y == p.y )
			return true;
		return false;
	}
	int x;
	int y;
};
