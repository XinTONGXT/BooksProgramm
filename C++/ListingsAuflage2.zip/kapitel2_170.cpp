////////////////////////////////////////////////////////////
// Listing 170 aus Kapitel 2
// Schematische Darstellung eines Exception-sicheren Destruktors

T::~T()
{
  try
  {
    Anweisung1;
    Anweisung2;
    // ...
  }
  catch( ... )
  {
  }
}
