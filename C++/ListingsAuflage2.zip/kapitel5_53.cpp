////////////////////////////////////////////////////////////
// Listing 53 aus Kapitel 5
// Definition einer Stringklasse mit anderen Eigenschaften

#include <iostream>
#include <string>
#include <cctype>
#include <set>

struct MyCharTraits : public std::char_traits<char>
{
  typedef unsigned int  size_t;
  static bool eq( const char& a, const char& b )
  {
    return std::tolower( a ) == std::tolower( b );
  }
  static bool lt( const char& a, const char& b )
  {
    return std::char_traits<char>::lt(std::tolower(a),
                                      std::tolower(b));
  }
  static int compare( const char *a,
                      const char *b, size_t n )
  {
    int ret = 0;
    for( size_t i = 0; i < n && ret == 0; ++i )
    {
      if(      lt( b[i], a[i] ) ) ret =  1;
      else if( lt( a[i], b[i] ) ) ret = -1;
    }
    return ret;
  }
};

typedef std::basic_string<char,MyCharTraits> MyString;
std::ostream& operator<<( std::ostream &os,
                          const MyString &s )
{ return os << s.c_str(); }

typedef std::set<std::string> BTree1;
typedef std::set<MyString>    BTree2;

int main()
{
    using namespace std;

    BTree1 t1;
    BTree2 t2;

    t1.insert( "arabisch" );
    t1.insert( "Arabien" );
    t1.insert( "afrikanisch" );
    t1.insert( "Afrika" );

    for( BTree1::iterator it1 = t1.begin();
         it1 != t1.end(); ++it1 )
        cout << *it1 << endl;

    cout << "**********" << endl;

    t2.insert( "arabisch" );
    t2.insert( "Arabien" );
    t2.insert( "afrikanisch" );
    t2.insert( "Afrika" );

    for( BTree2::iterator it2 = t2.begin();
         it2 != t2.end(); ++it2 )
        cout << *it2 << endl;

    return 0;
}
