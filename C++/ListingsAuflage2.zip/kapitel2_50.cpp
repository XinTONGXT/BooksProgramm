////////////////////////////////////////////////////////////
// Listing 50 aus Kapitel 2
// Eine verschachtelte Struktur

struct Kreis
{
	struct Punkt m;
	int r;
};
