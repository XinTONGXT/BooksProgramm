////////////////////////////////////////////////////////////
// Listing 39 aus Kapitel 6
// Einlesende Funktion

PersistenzObjekt* einlesen( std::istream &is )
{
	PersistenzObjekt *obj = NULL;
	std::string typestring;
	is >> typestring;
	if( /* �berpr�fe typestring auf Punkt */ )
	{
		int x, y;
		is >> x;
		is >> y;
		obj = new Punkt(x,y);
	}
	else if( /* �berpr�fe typestring auf sonstwas */ )
	{
		// ...
		obj = ...
	}

	return obj;
}
