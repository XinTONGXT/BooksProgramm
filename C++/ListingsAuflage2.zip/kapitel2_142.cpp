////////////////////////////////////////////////////////////
// Listing 142 aus Kapitel 2
// �berladener Operator

Complex operator+( const Complex &c1,
                   const Complex &c2 )

{
	Complex result;	
	result.r = c1.r + c2.r;
	result.i = c1.i + c2.i;
	return result;
}
