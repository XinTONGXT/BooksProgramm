////////////////////////////////////////////////////////////
// Listing 24 aus Kapitel 4
// Vollst�ndige Spezialisierung des Methodentemplates

template <>
class X<double,double>
{
public:
	void f();
};

void X<double,double>::f()
{
// Tu was...
}
