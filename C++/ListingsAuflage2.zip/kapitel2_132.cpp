////////////////////////////////////////////////////////////
// Listing 132 aus Kapitel 2
// Mehrfachvererbung mit Attributen

class A
{
public:
	int a;
};

class B
{
public:
	int b;
};

class X : public A, public B
{ /*...*/ };
