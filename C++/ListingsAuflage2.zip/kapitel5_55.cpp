////////////////////////////////////////////////////////////
// Listing 55 aus Kapitel 5
// Vergr��erung des Valarrays durch Aufruf von resize()

#include <iostream>
#include <valarray>

void print_out( const std::valarray<int> &va )
{
    for( unsigned i = 0; i < va.size(); ++i )
        std::cout << va[i] << std::endl;
}

int main()
{
    std::valarray<int> v(10);

    for( unsigned i = 0; i < 10; ++i )
        v[i] = 10 * (i+1);

    print_out( v );

    std::cout << "***" << std::endl;

    v.resize( 11 );

    print_out( v );

    return 0;
}
