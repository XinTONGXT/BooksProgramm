////////////////////////////////////////////////////////////
// Listing 133 aus Kapitel 2
// Adressverschiebung bei Upcast

// ...
int main()
{
    X x;
    A* pa = &x;
    B* pb = &x;

    std::cout << &x << std::endl;
    std::cout << pa << std::endl;
    std::cout << pb << std::endl;

    return 0;
}
