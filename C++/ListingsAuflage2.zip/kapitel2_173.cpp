////////////////////////////////////////////////////////////
// Listing 173 aus Kapitel 2
// Sicherung dynamisch allokierter Objekte durch Autopointer

#include <iostream>
#include <memory>

class X
{
public:
	X() { std::cout << "X::X()" << std::endl; }
	~X() { std::cout << "X::~X()" << std::endl; }
private:
	X( const X& );
};

int main()
{
	std::auto_ptr<X> p1 ( new X() );
	
	return 0;
}
