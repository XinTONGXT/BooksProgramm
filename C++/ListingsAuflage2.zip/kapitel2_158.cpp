////////////////////////////////////////////////////////////
// Listing 158 aus Kapitel 2
// �berladener Indexoperator

class Vector
{
	//...	
	ELEMENT operator[]( unsigned idx ) const;
};
