////////////////////////////////////////////////////////////
// Listing 16 aus Kapitel 4
// Syntax der expliziten Templateinstanziierung

template class Array<int,5>;
