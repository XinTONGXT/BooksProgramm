////////////////////////////////////////////////////////////
// Listing 43 aus Kapitel 4
// Template-Templateparameter

template< template <typename> class T >
class X
{
};
