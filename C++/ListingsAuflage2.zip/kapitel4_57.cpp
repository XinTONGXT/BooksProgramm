////////////////////////////////////////////////////////////
// Listing 57 aus Kapitel 4
// Implementierung von Vergleichsoperatoren f�r den Smart Pointer

template <typename T>
class SmartPointer
{
public:
	// ...
	friend
	inline bool operator==( const SmartPointer &p1,
	                        const SmartPointer &p2 )
	{
		return p1.pObj == p2.pObj;
	}
	friend
	inline bool operator!=( const SmartPointer &p1,
	                        const SmartPointer &p2 )
	{
		return p1.pObj != p2.pObj;
	}
	operator bool() const { return pObj!=0; }
	// ...
};
