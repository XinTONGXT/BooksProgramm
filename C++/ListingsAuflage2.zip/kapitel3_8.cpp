////////////////////////////////////////////////////////////
// Listing 8 aus Kapitel 3
// Verwendung eines Singletons auf Makrobasis

class MyClass
{
    DECLARE_SINGLETON(MyClass);

    void fachlicheFunktion1();
    void fachlicheFunktion2();
    ...
};

...
DEFINE_SINGLETON(MyClass);
