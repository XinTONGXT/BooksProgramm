////////////////////////////////////////////////////////////
// Listing 29 aus Kapitel 5
// Umformatierung von Streams �ber Iteratoren

#include <iostream>
#include <fstream>
#include <iterator>

int main()
{
	using namespace std;
	ifstream ind( "dat1.txt" );
	istream_iterator<int> ins( ind ), endofstream;
	ostream_iterator<int> outs( cout, " - " );

	while( ins != endofstream )
	{
		*outs++ = *ins++;
	}

	return 0;
}
