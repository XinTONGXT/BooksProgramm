////////////////////////////////////////////////////////////
// Listing 26 aus Kapitel 3
// Einsatz von �berladenen Operatoren f�r den Elementzugriff

class Zugriff
{
public:
	Zugriff() : k(0) {}
	Zugriff( Knoten *pk ) : k(pk) {}
	void Inc() { k = k->next; }
	void Dec() { k = k->prev; }
	bool IsValid() const { return k != 0; }
	ELEMENT get() const { return k->element; }
private:
	Knoten *k;
};
