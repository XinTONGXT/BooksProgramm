////////////////////////////////////////////////////////////
// Listing 32 aus Kapitel 2
// Einfache Funktionen

#include <iostream>

int f1( int i )
{
	return i * 2;
}

int f2( int i )
{
	return i * i;
}

int main()
{
	int i;
	i = f2( f1( 5 ) );
	std::cout << i << std::endl;
	return 0;
}
