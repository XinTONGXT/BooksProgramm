////////////////////////////////////////////////////////////
// Listing 13 aus Kapitel 3
// Die Implementierung des Knotens

class Knoten
{
public:
	Knoten( ELEMENT e ) : element(e), prev(0), next(0) {}
	ELEMENT element;
	Knoten *prev, *next;
};
