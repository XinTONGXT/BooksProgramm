////////////////////////////////////////////////////////////
// Listing 59 aus Kapitel 5
// Ver�nderung der Werte einer slice-Auswahl

// ...
v[slice(1,4,3)] = 0;
// ...
