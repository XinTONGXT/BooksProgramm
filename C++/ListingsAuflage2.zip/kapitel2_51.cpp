////////////////////////////////////////////////////////////
// Listing 51 aus Kapitel 2
// Zugriffe auf Strukturelemente

struct Kreis k1
k1.r = 5;
k1.m.x = 0;
k1.m.y = 0;
