////////////////////////////////////////////////////////////
// Listing 36 aus Kapitel 4
// Implementierung einer friend-Funktion in einer Klasse

class Punkt
{
public:
	int x, y;
	Punkt( int vx, int vy ) : x(vx), y(vy) {}

	friend
	bool operator==( const Punkt &p1, const Punkt &p2 )
	{
		return (p1.x==p2.x) && (p1.y==p2.y);
	}
};
