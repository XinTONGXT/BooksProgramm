////////////////////////////////////////////////////////////
// Listing 12 aus Kapitel 6
// Anwendung der using-Direktive auf einen Namensraum

#include <string>
#include <iostream>
	
void f()
{
	using namespace std;

	string s = "Text";
	cout << s << endl;

	// ...
}
