////////////////////////////////////////////////////////////
// Listing 167 aus Kapitel 2
// �ffnen von Dateien

//...
FILE *f = fopen( "daten.txt", "wt" );

fkt();
fclose( f );
//...
