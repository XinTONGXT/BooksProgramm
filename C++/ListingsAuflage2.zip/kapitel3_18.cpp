////////////////////////////////////////////////////////////
// Listing 18 aus Kapitel 3
// Die Zugriffsschnittstelle der Liste

class Liste
{
public:
	Liste() : anfang(0), ende(0) {}
	~Liste();
	void AddEnd( ELEMENT e );

	Zugriff Begin() { return Zugriff(anfang); }
	Zugriff End()   { return Zugriff(ende);   }
private:
	Knoten *anfang, *ende;
	Liste( const Liste & ); // verstecken!
};
