////////////////////////////////////////////////////////////
// Listing 117 aus Kapitel 2
// Elementsichtbarkeit bei privater Vererbung

class Basis
{
public:
	int b1;
protected:
	int b2;
private:
	int b3;
};

class S1 : private Basis
{
public:
	void f();
	using Basis::b1;
	using Basis::b2;
};

void S1::f()
{
	b1 = 0; // OK
	b2 = 0; // OK
	b3 = 0; // Nicht erlaubt! Compilefehler.
}

int main()
{
	S1 obj;
	obj.b1 = 0; // OK
	obj.b2 = 0; // OK
	obj.b3 = 0; // Nicht erlaubt! Compilefehler.

	return 0;
}
