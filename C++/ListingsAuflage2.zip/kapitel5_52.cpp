////////////////////////////////////////////////////////////
// Listing 52 aus Kapitel 5
// Definition einer auf wchar_t basierenden Stringklasse

#include <iostream>
#include <string>

typedef std::basic_string< wchar_t > wstring;

std::ostream& operator<<( std::ostream &os,
                          const wstring &ws )
{
    for( wstring::const_iterator it = ws.begin();
         it != ws.end(); ++it )
        os << (char)(*it);
    return os;
}

int main()
{
    wstring ws1 = L"Ein Test";

    std::cout << ws1 << std::endl;

    return 0;
}
