////////////////////////////////////////////////////////////
// Listing 48 aus Kapitel 4
// Beispiel eines generischen Mappings

#include <iostream>
#include <list>
#include <vector>
#include <string>

template <typename K, typename V,
          template <typename> class C>
class Mapping
{
public:
    void insert( const K& k, const V& v )
    {
        kc.push_back( k );
        vc.push_back( v );
    }
    const V* search( const K& k );
private:
    C<K> kc;
    C<V> vc;
};

template <typename K, typename V,
          template <typename> class C>
const V* Mapping<K,V,C>::search( const K& k )
{
    const V* p = 0;
    typename C<K>::const_iterator itk = kc.begin();
    typename C<V>::const_iterator itv = vc.begin();
    while( itk != kc.end() )
    {
        if( k == *itk )
        {
            p = &(*itv);
            break;
        }

        ++itk;
        ++itv;
    }
    return p;
}

// Trick zur Reduktion eines Templateparameters
template <typename T>
class MyList : public std::list<T> {};
template <typename T>
class MyVector : public std::vector<T> {};

int main()
{
    Mapping<int,std::string,MyVector> m;

    m.insert( 444, "Hans" );
    m.insert( 123, "Markus" );
    m.insert( 888, "Olaf" );
    m.insert( 100, "Robert" );
    std::cout << *(m.search( 888 )) << std::endl;

    return 0;
}
