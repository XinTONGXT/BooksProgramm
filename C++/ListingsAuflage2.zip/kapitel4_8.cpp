////////////////////////////////////////////////////////////
// Listing 8 aus Kapitel 4
// Referenz�bergabe und R�ckgabe bei Templatefunktion

template <class T>
T& min( T &a, T &b )
{
	return (a < b) ? a : b;
}
