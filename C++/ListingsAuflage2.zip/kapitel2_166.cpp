////////////////////////////////////////////////////////////
// Listing 166 aus Kapitel 2
// Allokation von Speicher

//...
char *p = (char*)malloc( X * sizeof(char) );

fkt();

free( p );
//...
