////////////////////////////////////////////////////////////
// Listing 13 aus Kapitel 4
// Methoden in einem Klassentemplate

template <typename T, unsigned n>
class Array
{
public:
    enum { size = n };
    T& operator[]( int i ) { return data[i]; }
    const T& max() const;
    const T& min() const;
private:
    T data[n];
};
