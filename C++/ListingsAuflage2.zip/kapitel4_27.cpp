////////////////////////////////////////////////////////////
// Listing 27 aus Kapitel 4
// Nichtqualifiziertes Einsetzen eines Operators

Punkt p1( 2, 3 );
Punkt p2( 3, 3 );
// ...
if( p1 == p2 )
{
	// ...
}
