////////////////////////////////////////////////////////////
// Listing 140 aus Kapitel 2
// Konstanter R�ckgabewert

const Complex operator+( const Complex &c1,
                         const Complex &c2 )
{
	return Complex( c1.r + c2.r, c1.i + c2.i );
}
