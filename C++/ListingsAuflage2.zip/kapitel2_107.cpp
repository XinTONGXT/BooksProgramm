////////////////////////////////////////////////////////////
// Listing 107 aus Kapitel 2
// Eine friend-Klasse

class A
{
public:
// ...
private:
	int x;
	friend class B;
};

class B
{
public:
	void f();
};

void B::f()
{
	A a;
	a.x = 5; // Zugriff nur durch friend-Stellung erlaubt.
}
