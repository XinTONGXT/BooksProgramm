////////////////////////////////////////////////////////////
// Listing 23 aus Kapitel 2
// Indizierung eines Arrays �ber einen Zeiger

	short buffer[100];
	int i;
	// ...
	for( i = 0; i < 100; ++i )
		buffer[i] = 0;
