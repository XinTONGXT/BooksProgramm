////////////////////////////////////////////////////////////
// Listing 14 aus Kapitel 5
// Anwendung eines ostringstream-Objekts als Textpuffer

#include <iostream>
#include <sstream>
#include <iomanip>

int main()
{
	using namespace std;
	ostringstream str;

	str << right;

	for( int i = 1; i < 7; ++i )
	{
		str << setw(7) << (i*i*i) << endl;
	}

	cout << str.str();

	return 0;
}
