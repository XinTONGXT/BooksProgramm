////////////////////////////////////////////////////////////
// Listing 32 aus Kapitel 4
// Eindeutige Qualifizierung in Templates

#include <iostream>

void f();

template<typename T>
class A
{
public:
	void f();
};

template<typename T>
class B : public A<T>
{
public:
	void g();
};

template<typename T>
void A<T>::f()
{
	std::cout << "A<T>::f()" << std::endl;
}

template<typename T>
void B<T>::g()
{
	// Der Aufruf von f() aus der Elternklasse.
	this->f();
	A<T>::f(); // alternativ
	// Der Aufruf der globalen Funktion f():
	::f();
}

void f()
{
	std::cout << "Die globale Funktion f()" << std::endl;
}

int main()
{
	B<int> obj;
	obj.g();

	return 0;
}
