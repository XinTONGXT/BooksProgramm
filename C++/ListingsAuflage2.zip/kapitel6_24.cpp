////////////////////////////////////////////////////////////
// Listing 24 aus Kapitel 6
// Logische Folge aus den Schritten 1 - 4

namespace test
{
	class X {};

	void f( X ) {}
}

int main()
{
	test::X x;

	f( x ); // test::f( test::X ) !

	return 0;
}
