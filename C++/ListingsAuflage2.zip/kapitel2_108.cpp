////////////////////////////////////////////////////////////
// Listing 108 aus Kapitel 2
// Eine friend-Funktion

void global_f();

class A
{
	// ...

	friend void global_f();
};
