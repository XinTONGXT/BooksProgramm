////////////////////////////////////////////////////////////
// Listing 35 aus Kapitel 3
// Ein verfeinertes Assertion-Template

template <class E, class A>
inline void Assert( A assertion, E exception )
{
	if( !assertion ) throw exception;
}
