////////////////////////////////////////////////////////////
// Listing 42 aus Kapitel 2
// Inlinefunktion

inline long zinsen( long betrag, double zinssatz )
{
	return (long)(betrag * zinssatz);
}
