////////////////////////////////////////////////////////////
// Listing 89 aus Kapitel 2
// Unterbundene implizite Konvertierung

p = v; // Ung�ltig! Implizite Konvertierung geht nicht.
p = Punkt(v); // Explizite Typenkonvertierung!
