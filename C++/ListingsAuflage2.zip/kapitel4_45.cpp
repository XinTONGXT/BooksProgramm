////////////////////////////////////////////////////////////
// Listing 45 aus Kapitel 4
// Verschachtelte Template-Templateparameter

template< template <typename> class T >
class X
{
    T<int> t;
};

template< template
          <template <typename> class Q>
          class T >
class Y
{
};
