////////////////////////////////////////////////////////////
// Listing 56 aus Kapitel 5
// Arithmetische Operationen auf Valarrays

#include <iostream>
#include <valarray>

void print_out( const std::valarray<int> &va )
{
    for( unsigned i = 0; i < va.size(); ++i )
        std::cout << va[i] << " ";
    std::cout << std::endl;
}

int main()
{
    int a[] = { 5, 4, 1, 2 };
    std::valarray<int> v1(a,4);
    std::valarray<int> v2(2,4);
    v2[0] =  1;
    v2[1] =  0;

    print_out( v1 );
    print_out( v2 );
    v1 += v2;
    print_out( v1 );
    v1 += 3;
    print_out( v1 );

    return 0;
}
