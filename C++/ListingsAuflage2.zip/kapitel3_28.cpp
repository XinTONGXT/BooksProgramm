////////////////////////////////////////////////////////////
// Listing 28 aus Kapitel 3
// {Operatoren f�r Dereferenzierung, Inkrement und Dekrement in der protecthbox{Zugriffsklasse

ELEMENT operator *() { return k->element; }
Zugriff& operator++() { Inc(); return *this; }
Zugriff  operator++(int)
{
	Zugriff tmp( *this );
	Inc();
	return tmp;
}
Zugriff& operator--() { Dec(); return *this; }
Zugriff  operator--(int)
{
	Zugriff tmp( *this );
	Dec();
	return tmp;
}
