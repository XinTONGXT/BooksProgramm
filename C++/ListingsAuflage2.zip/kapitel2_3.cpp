////////////////////////////////////////////////////////////
// Listing 3 aus Kapitel 2
// Verzweigungen im Pr�prozessorlauf anhand einer Definition

#ifdef BIGENDIAN
 #define HIGHBYTE RIGHTBYTE
 #define LOWBYTE  LEFTBYTE
#else // LITTLEENDIAN
 #define HIGHBYTE LEFTBYTE
 #define LOWBYTE  RIGHTBYTE
#endif
