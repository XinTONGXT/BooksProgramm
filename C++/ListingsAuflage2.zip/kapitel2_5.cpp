////////////////////////////////////////////////////////////
// Listing 5 aus Kapitel 2
// Beispiel: bedingte Compilierung

#ifdef __cplusplus
extern "C" {
#endif

int f()
{
	// ...
}

#ifdef __cplusplus
}
#endif
