////////////////////////////////////////////////////////////
// Listing 43 aus Kapitel 2
// Definition und Anwendung eines Makros

#define QUADRAT( x )  ( (x) * (x) )

int main()
{
	int i = 7;
	int j = QUADRAT( i );
	// ...
	return 0;
}
