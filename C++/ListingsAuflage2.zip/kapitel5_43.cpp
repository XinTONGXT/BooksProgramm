////////////////////////////////////////////////////////////
// Listing 43 aus Kapitel 5
// Transformation und Anh�ngen an neuen Container

// ...
list<int> l1;

l1.push_back( 1 );
l1.push_back( 2 );
l1.push_back( 3 );

for_each( l1.begin(), l1.end(), ausgabe(cout) );
list<int> l2;
transform( l1.begin(), l1.end(),
           back_inserter(l2), negate<int>() );
for_each( l2.begin(), l2.end(), ausgabe(cout) );
// ...
