////////////////////////////////////////////////////////////
// Listing 32 aus Kapitel 5
// Variable Parametrisierung eines Pr�dikats

#include <iostream>
#include <fstream>
#include <list>
#include <algorithm>

class ausgabe
{
public:
    ausgabe( std::ostream &s ) : os(s) {}
    void operator()( int i ) const
    { os << i << std::endl; }
private:
    std::ostream &os;
};

int main()
{
    using namespace std;

    list<int> l1;

    l1.push_back( 1 );
    l1.push_back( 2 );
    l1.push_back( 3 );

    for_each( l1.begin(), l1.end(), ausgabe(cout) );
    ofstream datei( "test.txt" );
    for_each( l1.begin(), l1.end(), ausgabe(datei) );

    return 0;
}
