////////////////////////////////////////////////////////////
// Listing 69 aus Kapitel 2
// Ein Punkt in einem zweidimensionalen Koordinatensystem

struct Punkt
{
	int x;
	int y;
};
