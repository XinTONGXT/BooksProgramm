////////////////////////////////////////////////////////////
// Listing 63 aus Kapitel 5
// Vorgezogenes L�schen des Objekts am Autopointer

// ..
int main()
{
    using std::auto_ptr;

    auto_ptr<X> p( new X() );

    p.reset();

    p = auto_ptr<X>(new X());

    return 0;
}
