////////////////////////////////////////////////////////////
// Listing 27 aus Kapitel 6
// Inklusion einer Klassendeklaration mit V-Tabelle in mehreren Modulen

// Headerdatei BASIS.H
class Basis
{
public:
	virtual ~Basis();
};

// Modul BASIS.CPP
#include "BASIS.H"
Basis::~Basis()
{
}

// Modul KONKRET.CPP
#include "BASIS.H"

class Konkret : public Basis
{
};

int main()
{
	Konkret k;
	return 0;
}
