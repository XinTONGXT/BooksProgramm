////////////////////////////////////////////////////////////
// Listing 71 aus Kapitel 2
// Eine Initialisierungsliste

// ...
Punkt::Punkt( int vx, int vy ) : x(vx), y(vy)
{
}
// ...
