////////////////////////////////////////////////////////////
// Listing 46 aus Kapitel 2
// Zugriff auf den allozierten Speicher

long *p;
p = (long *)malloc( 3 * sizeof(long) );
if( p != 0 )
{
	p[0] = 42;     /* schreibender Zugriff */
	p[1] = p[0]/7; /* Lese- und Schreibzugriff */
	p[2] = p[1]/2; /* Lese- und Schreibzugriff */

	free(p);
}
