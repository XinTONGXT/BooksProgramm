////////////////////////////////////////////////////////////
// Listing 58 aus Kapitel 2
// �ffnen der Sichtbarkeit der Attribute

class Punkt
{
public:
	int x;
	int y;
};

Punkt p;
p.x = 0; // OK!
p.y = 0; // OK!
