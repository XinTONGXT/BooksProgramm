////////////////////////////////////////////////////////////
// Listing 30 aus Kapitel 2
// Der Bitoperator &

#include <iostream>

int main()
{
	int a = 3;
	int b = 6;
	int c = a & b;
	std::cout << c << std::endl;
	return 0;
}
