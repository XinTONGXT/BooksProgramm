////////////////////////////////////////////////////////////
// Listing 7 aus Kapitel 2
// #ifndef anders ausgedr�ckt

#if !defined(EXTC)
 #if defined(__cplusplus)
  #define EXTC extern "C"
 #else
  #define EXTC
 #endif
#endif // EXTC
...
