////////////////////////////////////////////////////////////
// Listing 16 aus Kapitel 3
// Methoden der Liste

class Liste
{
public:
	Liste() : anfang(0), ende(0) {}
	~Liste();
	void AddEnd( ELEMENT e );
private:
	Knoten *anfang, *ende;
	Liste( const Liste & ); // verstecken!
};

// ...

Liste::~Liste()
{
	Knoten *t = anfang;
	while( t )
	{
		Knoten *n = t->next;
		delete t;
		t = n;
	}
}

void Liste::AddEnd( ELEMENT e )
{
	Knoten *k = new Knoten( e );
	if( ende )
	{
		ende->next = k;
		k->prev = ende;
		ende = k;
	}
	else
	{
		anfang = ende = k;
	}
}
