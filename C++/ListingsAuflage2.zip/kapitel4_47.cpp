////////////////////////////////////////////////////////////
// Listing 47 aus Kapitel 4
// Reduzierte Form

template< template < typename Q,
                     typename = Q*
                   > class T >
class X
{
    T<int> t;
};
