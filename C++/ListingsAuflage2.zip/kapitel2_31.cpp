////////////////////////////////////////////////////////////
// Listing 31 aus Kapitel 2
// Deklaration und Anweisungen

	int a, b;         /* Deklarationen */
	a = 5;            /* Anweisung */
	b = a + 3;        /* Anweisung */
	funktion( a, b ); /* Anweisung */
