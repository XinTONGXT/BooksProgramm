////////////////////////////////////////////////////////////
// Listing 20 aus Kapitel 5
// Drei m�gliche Zugriffsarten auf den Vektor

#include <iostream>
#include <vector>

int main()
{
    std::vector<int> l;

    l.push_back( 3 );
    l.push_back( 5 );
    l.push_back( 7 );

    for( std::vector<int>::iterator it = l.begin();
         it != l.end();
         ++it )
        std::cout << *it << std::endl;

    std::cout << std::endl;

    for( int i = 0; i < l.size(); i++ )
        std::cout << l[i] << std::endl;

    std::cout << std::endl;

    for( int j = 0; j < l.size(); j++ )
        std::cout << l.at(j) << std::endl;

    return 0;
}
