////////////////////////////////////////////////////////////
// Listing 145 aus Kapitel 2
// Anwendung �berladener Operatoren

#include <iostream>

struct Complex
{
		double r;
    double i;
};

Complex operator+( const Complex &c1,
                   const Complex &c2 )
{
    Complex result;
    result.i = c1.i + c2.i;
    result.r = c1.r + c2.r;
    return result;
}
std::ostream& operator<<( std::ostream &os,
                          const Complex &c )
{
    return os << "(" << c.r << "/i" << c.i << ")";
}
int main()
{
    Complex z1 = {3,5};
    Complex z2 = {2,1};

    Complex z3 = z1 + z2;

    std::cout << z3 << std::endl;

    return 0;
}
