////////////////////////////////////////////////////////////
// Listing 5 aus Kapitel 3
// Singleton mit statischer Instanz

class Singleton
{
   public:
     static Singleton& exemplar();

   private:
     Singleton() {}
     Singleton( const Singleton& );
};

Singleton& Singleton::exemplar()
{
  static Singleton instanz;
  return instanz;
}
