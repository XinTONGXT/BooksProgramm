////////////////////////////////////////////////////////////
// Listing 150 aus Kapitel 2
// �berladung des Subtraktionsoperators

Complex Complex::operator-( const Complex &c ) const
{
    Complex result = { r - c.r, i - c.i };
    return result;
}
