////////////////////////////////////////////////////////////
// Listing 34 aus Kapitel 6
// Operator new mit Sicherungsabfrage

void* X::operator new( std::size_t s )
{
	if( s != sizeof(X) )
		return ::operator new(s);

	return getMemoryFromXPool();
}
