////////////////////////////////////////////////////////////
// Listing 64 aus Kapitel 5
// Automatisches Reset durch Neuzuweisung des Autopointers

// ...
int main()
{
    using std::auto_ptr;

    auto_ptr<X> p( new X() );

    p = auto_ptr<X>(new X());

    return 0;
}
