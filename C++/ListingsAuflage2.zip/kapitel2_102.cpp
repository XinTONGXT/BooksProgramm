////////////////////////////////////////////////////////////
// Listing 102 aus Kapitel 2
// Qualifizierung bei Mehrfachvererbung

class X
{
	public:
		int x;
};

class A1 : public X
{};

class A2 : public X
{};

class B : public A1, public A2
{};

int main()
{
	B b;
	b.x = 0;     // Compilefehler!
	b.X::x = 0;  // Compilefehler!
	b.A1::x = 0; // OK
	b.A2::x = 0; // OK

 // ...
}
