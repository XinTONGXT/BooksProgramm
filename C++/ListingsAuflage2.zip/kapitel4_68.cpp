////////////////////////////////////////////////////////////
// Listing 68 aus Kapitel 4
// Instanziierung der Implementierungen

// TeplateInst.cpp
#include "Vector.h"
#include "VectorImpl.h"

// Hier folgen die Instanziierungen der Templates,
// die im Projekt gebraucht werden.
template class Vector<int>;
template class Vector<double>;

// ...
