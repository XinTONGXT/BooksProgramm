////////////////////////////////////////////////////////////
// Listing 59 aus Kapitel 4
// Smart Pointer in einem Container

// ...
typedef Liste<SmartPointer<X> > Container;

int main()
{
	Container l;
	l.AddEnd( new X() );
	l.AddEnd( new X() );

	return 0;
}
