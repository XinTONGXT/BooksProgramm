////////////////////////////////////////////////////////////
// Listing 103 aus Kapitel 2
// ADL versus Qualifizierung

namespace A
{
	class X {};

	void f(const X&)
	{
	}
}

namespace B
{
	void f(const A::X&)
	{
	}
}

int main()
{
	A::X x;

	f(x);   // Compiler findet A::f() durch ADL
	A::f(x) // Compiler findet A::f() durch Qualifizierung
	B::f(x) // ruft B::f()

	// ...
}
