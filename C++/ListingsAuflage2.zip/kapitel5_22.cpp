////////////////////////////////////////////////////////////
// Listing 22 aus Kapitel 5
// Ein Demobeispiel zur STL-Map

#include <iostream>
#include <map>
#include <string>

int main()
{
	using namespace std;
	map<string,string> dictionary;

	dictionary["monitor"]  = "Bildschirm";
	dictionary["keyboard"] = "Tastatur";
	dictionary["mouse"] 	 = "Maus";

	cout << dictionary["keyboard"] << endl;

	return 0;
}
