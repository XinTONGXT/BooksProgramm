////////////////////////////////////////////////////////////
// Listing 19 aus Kapitel 3
// Implementierung der Zugriffsklasse

class Zugriff
{
public:
	Zugriff() : k(0) {}
	Zugriff( Knoten *pk ) : k(pk) {}
	void Inc() { k = k->next; }
	void Dec() { k = k->prev; }
	bool IsValid() const { return k != 0; }
	ELEMENT get() const { return k->element; }
private:
	Knoten *k;
};
