////////////////////////////////////////////////////////////
// Listing 54 aus Kapitel 4
// Ein Template-basierter Smart Pointer

template <typename T>
class SmartPointer
{
public:
	SmartPointer( T *const ptr ) : pObj(ptr) {}
	~SmartPointer() { delete pObj; }

	// Zugriffe
	T * operator->() { return  pObj; }
	T & operator*()  { return *pObj; }
private:
	T *pObj;
};
