////////////////////////////////////////////////////////////
// Listing 161 aus Kapitel 2
// Mehrere catch-Bl�cke

#include <iostream>
using namespace std;

void fa()
{
	cout << "Aufruf von fa()" << endl;
}

void fb()
{
	cout << "Aufruf von fb()" << endl;
	throw int(42);
}
void fc()
{
	cout << "Aufruf von fc()" << endl;
}

int main()
{
	try
	{
		fa();
		fb();
		fc();
	}
	catch( double d )
	{
		cout << "Ausnahme vom Typ double" << endl;
		cout << "Wert: " << d << endl;
	}
	catch( int i )
	{
		cout << "Ausnahme vom Typ int" << endl;
		cout << "Wert: " << i << endl;
	}
	return 0;
}
