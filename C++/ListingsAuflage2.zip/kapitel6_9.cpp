////////////////////////////////////////////////////////////
// Listing 9 aus Kapitel 6
// Namensr�ume �ber mehrere Headerdateien

// A.h
namespace myLib
{
	class A { /* ... */ };
}
	
// B.h	
namespace myLib
{
	class B { /* ... */ };
}
