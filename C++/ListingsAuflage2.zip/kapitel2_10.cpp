////////////////////////////////////////////////////////////
// Listing 10 aus Kapitel 2
// Die Anwendung des Pr�prozessoroperators,,##

#include <iostream>

#define SOURCE "Datei: "##__FILE__
#define TRACE( msg ) std::cerr << \
(SOURCE##" => "##msg)<<std::endl;

int main()
{
	TRACE( "Eine Debugmeldung" );

	return 0;
}
