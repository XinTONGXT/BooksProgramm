////////////////////////////////////////////////////////////
// Listing 24 aus Kapitel 5
// Ein Demobeispiel zum STL-Stack

#include <iostream>
#include <string>
#include <list>
#include <vector>
#include <deque>
#include <stack>

template <typename STACK>
void WriteOut( STACK &stack )
{
	using std::cout;
	using std::endl;
	while( stack.size() )
	{
		cout << stack.top() << endl;
		stack.pop();
	}
}

int main()
{
	using namespace std;
	stack< string, vector<string> > vs;
	stack< string, list<string> >   ls;
	stack< string, deque<string> >  ds;

	vs.push( "Erdbeere" );
	vs.push( "Aprikose" );
	vs.push( "Kirsche" );

	ls.push( "Kartoffel" );
	ls.push( "Kohlrabi" );
	ls.push( "Zwiebel" );

	ds.push( "Bohne" );
	ds.push( "Linse" );
	ds.push( "Erbse" );

	WriteOut( vs );
	cout << "***" << endl;
	WriteOut( ls );
	cout << "***" << endl;
	WriteOut( ds );

	return 0;
}
