////////////////////////////////////////////////////////////
// Listing 39 aus Kapitel 2
// Aufruf der Funktion �ber den Funktionszeiger durch die Klammern

// Aufruf der Funktion �ber den Zeiger.
int i = fp(7,3.3);
