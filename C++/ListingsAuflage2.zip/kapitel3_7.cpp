////////////////////////////////////////////////////////////
// Listing 7 aus Kapitel 3
// Template-Implementierung der Elternklasse(n)

template <class Derived>
class Singleton
{
   public:
     static Derived& exemplar();

   protected:
     Singleton() {}

   private:
     Singleton( const Singleton& );
};

template <class Derived>
Derived& Singleton<Derived>::exemplar()
{
  static Derived instanz;
  return instanz;
}

Verwendung:

class ChildA : public Singleton<ChildA>
{  ...  };

class ChildB : public Singleton<ChildB>
{  ...  };
