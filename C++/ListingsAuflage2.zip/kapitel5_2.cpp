////////////////////////////////////////////////////////////
// Listing 2 aus Kapitel 5
// �berladen des Shift-Operators zur Verwendung als Ausgabeoperator

struct Complex
{
	double r;
	double i;
};

std::ostream& operator<<( std::ostream &os,
                          const Complex &c )
{
	os << "(" << c.r << "/i" << c.i << ")";
	return os;
}
