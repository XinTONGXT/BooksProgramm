////////////////////////////////////////////////////////////
// Listing 31 aus Kapitel 4
// Uneindeutiges Compileergebnis bei fehlender Qualifizierung in Templates

#include <iostream>

void f();

template<typename T>
class A
{
public:
	void f();
};

template<typename T>
class B : public A<T>
{
public:
	void g();
};

template<typename T>
void A<T>::f()
{
	std::cout << "A<T>::f()" << std::endl;
}

template<typename T>
void B<T>::g()
{
	f(); // Welches f() ist hier gemeint?
}

void f()
{
	std::cout << "Die globale Funktion f()" << std::endl;
}

int main()
{
	B<int> obj;

	obj.g();

	return 0;
}
