////////////////////////////////////////////////////////////
// Listing 73 aus Kapitel 2
// Korrekte Initialisierungsliste

class Punkt
{
public:
	Punkt( int vx, int vy ) : x(vx), y(vy) {}
	int x;
	int y;
};

class Kreis
{
public:
	Kreis( const Punkt &vm, double vr )
	: m(vm.x,vm.y), r(vr) {}

	Punkt m;
	double r;
};
