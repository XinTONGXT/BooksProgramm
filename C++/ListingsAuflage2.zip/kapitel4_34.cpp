////////////////////////////////////////////////////////////
// Listing 34 aus Kapitel 4
// Qualifizierung des rebind-Templates

template <class T, class A = std::allocator<T> >
class Container
{
	// ...
	class Node { /* ... */ };
	typedef
	  typename A::template rebind<Node>::other
	    NodeAllocator;
	// ...
};
