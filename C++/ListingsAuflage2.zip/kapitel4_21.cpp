////////////////////////////////////////////////////////////
// Listing 21 aus Kapitel 4
// Partielle Spezialisierung eines Templates

template <typename T, unsigned n>
class Array<T*,n>
{
public:
    enum { size = n };
    T& operator[]( int i ) { return data[i]; }
private:
    T data[n];
};
