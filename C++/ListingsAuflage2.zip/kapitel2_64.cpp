////////////////////////////////////////////////////////////
// Listing 64 aus Kapitel 2
// Der this-Zeiger

double Kreis::Umfang()
{
	return 2.0 * this->r * 3.141;
}

double Kreis::Flaeche()
{
	return 3.141 * this->r * this->r;
}
