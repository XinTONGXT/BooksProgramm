////////////////////////////////////////////////////////////
// Listing 20 aus Kapitel 3
// Anwendung der Liste

// ...
#include <iostream>

int main()
{
	Liste liste;

	liste.AddEnd( 3 );
	liste.AddEnd( 5 );
	liste.AddEnd( 7 );

	Zugriff z1 = liste.Begin();
	Zugriff z2 = liste.End();
	while( z1.IsValid() && z2.IsValid() )
	{
		std::cout << z1.get() << "\t"
		          << z2.get() << std::endl;

		z1.Inc();
		z2.Dec();
	}
	
	return 0;
}
