////////////////////////////////////////////////////////////
// Listing 5 aus Kapitel 5
// Whitespace l�schende Wirkungsweise des Eingabeoperators

// Streambeispiel5.cpp
#include <iostream>
int main()
{
	char c;
	while( std::cin >> c )
		std::cout << c;

	return 0;
}
