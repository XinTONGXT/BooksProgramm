////////////////////////////////////////////////////////////
// Listing 138 aus Kapitel 2
// Const-Maskierung

class Kreis
{
	public:
		Kreis( Punkt const &p, double radius );
		// ...
		double Umfang() const;
	private:
		Punkt m;
		double r;
};
// ...
double Kreis::Umfang() const
{
	return 2.0 * r * 3.141;
}
