////////////////////////////////////////////////////////////
// Listing 58 aus Kapitel 4
// Der Test der Smart-Pointer-Klasse

#include <list>
#include <cstdio>

class X
{
public:
    X()  { std::printf("X::X()\n"); }
    ~X() { std::printf("X::~X()\n"); }

    void f() { std::printf("X::f()\n"); }
private:
    X( const X& ); // verstecken!
};

void func( SmartPointer<X> p )
{
    p->f();
}

int main()
{
    SmartPointer<X> p1 = new X();
    SmartPointer<X> p2 = p1;
    SmartPointer<X> p3 = new X();
    SmartPointer<X> p4 = new X();

    p1->f();
    (*p2).f();
    p1 = p3; // Das erste Objekt wird nicht gel�scht.
    p4 = p3; // Das dritte Objekt wird gel�scht.
    func( p1 );

    return 0;
}
