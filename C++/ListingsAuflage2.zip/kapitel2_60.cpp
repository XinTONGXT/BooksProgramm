////////////////////////////////////////////////////////////
// Listing 60 aus Kapitel 2
// Die drei M�glichkeiten der Konstantendefinition in Klassen

class X
{
public:

	X() : KONSTANTE1(42) {}

	const int KONSTANTE1;

	static const int KONSTANTE2;

	enum{ KONSTANTE3 = 42 };
};

const int X::KONSTANTE2 = 42;
