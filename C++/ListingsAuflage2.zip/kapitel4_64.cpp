////////////////////////////////////////////////////////////
// Listing 64 aus Kapitel 4
// Ung�ltige doppelte Instanziierung

template void X<int>::f();
template class X<int>; // Fehler!
