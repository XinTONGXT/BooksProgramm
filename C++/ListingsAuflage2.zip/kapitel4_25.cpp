////////////////////////////////////////////////////////////
// Listing 25 aus Kapitel 4
// Vorgabeargument in der Templateparameterliste

template<typename T, template U = int>
class X { /*...*/ };

X<double> x1; // entspricht X<double,int>
X<double, char> x1;
