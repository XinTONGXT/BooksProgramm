////////////////////////////////////////////////////////////
// Listing 10 aus Kapitel 5
// Ein Manipulator mit einem Parameter

#include <iostream>
#include <iomanip>

int main()
{
	using namespace std;

	cout << right;
	
	for( int i = 1; i < 7; ++i )
	{
		cout << setw(7) << (i*i*i) << endl;
	}

	return 0;
}
