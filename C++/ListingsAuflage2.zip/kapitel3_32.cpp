////////////////////////////////////////////////////////////
// Listing 32 aus Kapitel 3
// Eine separate Methode f�r den Invariantencheck

inline void Vektor::checkInvariant()
{
#ifdef __DEBUG__
	if( capacity < 1 || size > capacity || buf == 0 )
		throw SomeException();
#endif
}
