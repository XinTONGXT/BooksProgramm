////////////////////////////////////////////////////////////
// Listing 126 aus Kapitel 2
// G�ltige Konvertierungen mit static_cast<>()

class X
{
public:
	X( int i ) {}
};

void f( const X &obj )
{
// ...
}

int main()
{
	double d = 55.9;
	int i = static_cast<int>(d);

	f( static_cast<X>(i) );

	return 0;
}
