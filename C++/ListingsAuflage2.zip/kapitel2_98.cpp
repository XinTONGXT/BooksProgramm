////////////////////////////////////////////////////////////
// Listing 98 aus Kapitel 2
// Zuordnung einer Methode zu einer Klasse

double Kreis::Umfang() const
{
	// ...
}
