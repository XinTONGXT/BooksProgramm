////////////////////////////////////////////////////////////
// Listing 19 aus Kapitel 5
// Variierung des Datencontainers im fachlichen Code

#include <iostream>
#include <list>
#include <vector>

// typedef std::list<int> MyContainer;
typedef std::vector<int> MyContainer;

int main()
{
	MyContainer l;

	l.push_back( 3 );
	l.push_back( 5 );
	l.push_back( 7 );

	for( MyContainer::iterator it = l.begin();
	     it != l.end();
	     ++it )
	     std::cout << *it << std::endl;

	return 0;
}
