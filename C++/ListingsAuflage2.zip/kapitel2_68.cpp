////////////////////////////////////////////////////////////
// Listing 68 aus Kapitel 2
// �ffentliche Vererbung

class A
{
public:
	int x;
};

class B : public A
{
};
