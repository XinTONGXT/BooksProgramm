////////////////////////////////////////////////////////////
// Listing 11 aus Kapitel 2
// Anwendung des sizeof-Operators

#include <iostream>

int main()
{
	std::cout << sizeof(short) << std::endl;
	std::cout << sizeof(int) << std::endl;
	std::cout << sizeof(long) << std::endl;
	std::cout << sizeof(float) << std::endl;
	std::cout << sizeof(double) << std::endl;

	int x = 42;

	std::cout << "Der Wert " << x
	          << " wird in einer Variablen mit der Gr��e "
	          << sizeof(x) << " gehalten." << std::endl;

	return 0;
}
