////////////////////////////////////////////////////////////
// Listing 171 aus Kapitel 2
// Implementierung einer Logfile-Klasse mit Exceptions

#include <iostream>
#include <memory>
#include <string>
#include <stdexcept>
#include <cstdio>
#include <strstream>
using namespace std;

class Logfile_exception : public std::exception
{
public:
   Logfile_exception()
   : std::exception(), txt("logfile exception") {}
   Logfile_exception( const Logfile_exception& e )
   : std::exception( e ), txt("logfile exception") {}
   const char *what( ) const throw();
private:
   const char *const txt;
};

class Logfile
{
	public:
		Logfile( const char *fname )
		throw( std::bad_alloc, Logfile_exception );
		~Logfile() throw();
		
		void write( const char *str );	
		Logfile& operator<<( const char *str )
		{ write( str ); return *this; }
		Logfile& operator<<( int i );	

	private:
		Logfile( const Logfile& ); // to hide!
		FILE *f;
		char *txt;
};

const char * Logfile_exception::what( ) const throw()
{ return txt; }

Logfile::Logfile( const char *fname )
throw(std::bad_alloc, Logfile_exception)
: txt( new char [1024] )
{
	f = fopen( fname, "wt" );
	if( ! f )
	{
		delete [] txt;
		throw Logfile_exception();
	}
}

Logfile::~Logfile() throw()
{
	delete [] txt;
	fclose( f );
}

void Logfile::write( const char *str )
{
	fputs( str, f );
}

Logfile& Logfile::operator<<( int i )
{
	txt[0] = '\0';
	std::strstream str( txt, 1024 );
	str << i;
	str << '\0';
	write( txt );
	return *this;
}


int main()
{
	try
	{
		Logfile l( "logfile.txt" );
		l << "Ein Testeintrag\n";
		l << 42;
	}
	catch( std::bad_alloc &e )
	{
		cerr << e.what() << endl;
	}
	catch( Logfile_exception &e )
	{
		cerr << e.what() << endl;
	}
	
	return 0;
}
