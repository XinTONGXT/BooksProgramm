////////////////////////////////////////////////////////////
// Listing 14 aus Kapitel 6
// Integration eines ganzen Namensraums

namespace myPrj
{
	using namespace std;
}
