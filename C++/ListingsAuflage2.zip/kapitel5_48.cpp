////////////////////////////////////////////////////////////
// Listing 48 aus Kapitel 5
// Iteratorzugriff auf ein std::string-Objekt

#include <iostream>
#include <string>

int main()
{
    using namespace std;

    string s( "Test" );

    cout << s << endl;

    for( string::iterator it = s.begin();
         it != s.end(); ++it )
        cout << *it << " ";

    return 0;
}
