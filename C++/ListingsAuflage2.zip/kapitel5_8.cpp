////////////////////////////////////////////////////////////
// Listing 8 aus Kapitel 5
// Definition einer Feldbreite in einer Ausgabe

#include <iostream>

int main()
{
	using namespace std;

	cout.flags(ios_base::right);

	for( int i = 1; i < 7; ++i )
	{
		cout.width(7);
		cout << (i*i*i) << endl;
	}

	return 0;
}
