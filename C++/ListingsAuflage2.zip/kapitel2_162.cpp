////////////////////////////////////////////////////////////
// Listing 162 aus Kapitel 2
// Hierarchische Exceptionhandler

#include <iostream>
using namespace std;
class EA {};
class EB {};

void e()
{
	throw EA();
}

void f()
{
	try
	{
		e();
	}
	catch( EB &e )
	{
		cout << "Die Exception EB ist aufgetreten!" << endl;
	}
}

int main()
{
	try
	{
		f();
	}
	catch( EA &e )
	{
		cout << "Die Exception EA ist aufgetreten!" << endl;
	}

	return 0;
}
