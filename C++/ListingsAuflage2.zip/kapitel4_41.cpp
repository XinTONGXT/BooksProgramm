////////////////////////////////////////////////////////////
// Listing 41 aus Kapitel 4
// Nicht standardkonformer Template-Code

template <typename Container>
void print_out( const Container &c )
{
	// Die folgende Zeile ist nicht Standard konform!
	Container::const_iterator it = c.begin();
	while( it != c.end() )
	{
		std::cout << *it << std::endl;
		++it;
	}
}
