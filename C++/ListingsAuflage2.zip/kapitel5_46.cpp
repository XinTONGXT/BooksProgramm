////////////////////////////////////////////////////////////
// Listing 46 aus Kapitel 5
// Inputiterator durch back_inserter

// ...
int main()
{
    using namespace std;

    list<int> l;
    vector<int> v;

    l.push_back( 7 );
    l.push_back( 4 );
    l.push_back( 7 );

    copy( l.begin(), l.end(), back_inserter(v) );
    for_each( v.begin(), v.end(), ausgabe(cout) );

    return 0;
}
