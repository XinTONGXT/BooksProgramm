////////////////////////////////////////////////////////////
// Listing 148 aus Kapitel 2
// Kopie des R�ckgabewertes

Complex operator+( const Complex &c1,
                   const Complex &c2 )
{
    Complex result = { c1.r + c2.r, c1.i + c2.i };
    return result;
}
