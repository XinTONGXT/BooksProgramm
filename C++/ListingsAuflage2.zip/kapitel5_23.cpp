////////////////////////////////////////////////////////////
// Listing 23 aus Kapitel 5
// Ein Programm zum Z�hlen von W�rtern in Texten

#include <iostream>
#include <string>
#include <map>

int main()
{
	using namespace std;
	typedef map<string,unsigned int> WordMap;
	WordMap m;

	while( !cin.eof() )
	{
		string s;
		cin >> s;
		if( !cin.eof() )
			m[s] += 1; // Hinzuf�gen und aufz�hlen.
	}

	cout << "Wort\tHaeufigkeit" << endl;
	for( WordMap::iterator i = m.begin();
	     i != m.end(); ++i )
	{
		cout << i->first << "\t" << i->second << endl;
	}

	return 0;
}
