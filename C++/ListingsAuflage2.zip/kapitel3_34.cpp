////////////////////////////////////////////////////////////
// Listing 34 aus Kapitel 3
// Anwendung der Assertion-Templates

void f1( unsigned i)
{
	Assert<Error>(i != 0);

	// ...
}

void f2( unsigned i )
{
	Assert<Error>(NDEBUG || i != 0);

	// ...
}
