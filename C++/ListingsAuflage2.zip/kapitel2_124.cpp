////////////////////////////////////////////////////////////
// Listing 124 aus Kapitel 2
// Typische Elemente einer Basisklasse

// Pseudocode
class Grafikelement
{
public:
	virtual ~Grafikelement();
	virtual void zeichne( Zeichenflaeche *zf ) = 0;
};

// In der CPP-Datei
Grafikelement::~Grafikelement() {}
