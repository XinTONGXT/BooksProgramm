////////////////////////////////////////////////////////////
// Listing 25 aus Kapitel 2
// Referenzsyntax

	int i;
	int &r = i;
	// ...
	r = 7;
	printf( "%d\n", i );
