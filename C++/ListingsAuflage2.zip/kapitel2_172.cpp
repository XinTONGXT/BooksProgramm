////////////////////////////////////////////////////////////
// Listing 172 aus Kapitel 2
// Schema einer Fehlerbehandlung in einem Konstruktor

Logfile::Logfile(char *fname)
throw(std::bad_alloc, Logfile_exception)
: txt( new char [1024] )
{
  f = fopen( fname, "wt" ); // Standardfall
  if( ! f )                 // 1. Zeile Fehlerbehandlung
  {                         // 2. Zeile Fehlerbehandlung
    delete [] txt;          // 3. Zeile Fehlerbehandlung
    throw Logfile_exception(); // 4. Zeile Fehlerb.
  }                         // 5. Zeile Fehlerbehandlung
}
