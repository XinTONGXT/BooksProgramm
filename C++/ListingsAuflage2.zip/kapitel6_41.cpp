////////////////////////////////////////////////////////////
// Listing 41 aus Kapitel 6
// Einfaches Objektpooling

#include <cstddef>
#include <cstdlib>

template <typename T>
struct ObjFrameBlock
{
	typedef unsigned char byte;
	typedef T element_type;
	byte data[ sizeof(T) ];
};

template <typename T>
struct ObjFrame : public ObjFrameBlock<T>
{
	ObjFrame() : next(NULL), prev(NULL) {}
	void* getData() { return ObjFrameBlock<T>::data; }
	ObjFrame *next, *prev;
};
template <typename T, unsigned int s = 100>
class ObjPool
{
public:
	typedef T           element_type;
	typedef ObjFrame<T> frame_type;
	ObjPool();
	~ObjPool();
	
	bool isIn( const void *p ) const
	{
		return    buffer[0].getData() <= p
		       && p <= buffer[poolsize-1].getData();
	}
	void *getMemForObj()
	{
		void *ret = NULL;
		if( free )
		{
			frame_type *f = free;
			frame_type *n = free->next;
			if( n ) n->prev = NULL;
			free = n;

			f->next = used;
			if( used ) used->prev = f;
			used = f;
				
			ret = f;
			n++;
		}
		return ret;
	}
	void freeMemOfObj( void * );

	std::size_t numberObjects() const { return n; }
private:
	frame_type *buffer;
	frame_type *free;
	frame_type *used;
	std::size_t n;
	enum { poolsize = s };
};

template <typename T, unsigned int s>
ObjPool<T,s>::ObjPool() : n(0), free(NULL), used(NULL)
{
	buffer = new frame_type[poolsize];
	for( int i = 0; i < poolsize; i++ )
	{
		frame_type *f = &buffer[i];
		if( free )
		{
			free->prev = f;	
		}
		f->next = free;
		free = f;
	}
}

template <typename T, unsigned int s>
ObjPool<T,s>::~ObjPool()
{
	delete [] buffer;
}

template <typename T, unsigned int s>
void ObjPool<T,s>::freeMemOfObj( void *p )
{
  typedef ObjFrameBlock<element_type> block_type;
	if( isIn( p ) )
	{
		n--;
		block_type *b = reinterpret_cast<block_type*>(p);
		frame_type *f = static_cast<frame_type*>(b);

		frame_type *p = f->prev;
		frame_type *n = f->next;
		if( f == used ) used = n;
		if(p) p->next = n;
		if(n) n->prev = p;

		f->next = free;
		if( free ) free->prev = f;
		free = f;
	}
}
