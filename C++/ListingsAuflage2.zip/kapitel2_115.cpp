////////////////////////////////////////////////////////////
// Listing 115 aus Kapitel 2
// Elementsichtbarkeit bei �ffentlicher Vererbung

class Basis
{
public:
	int b1;
protected:
	int b2;
private:
	int b3;
};

class S2 : public Basis
{
public:
	void f();
};

void S2::f()
{
	b1 = 0; // OK
	b2 = 0; // OK
	b3 = 0; // Nicht erlaubt! Compilefehler.
}

int main()
{
	S2 obj;
	obj.b1 = 0; // OK
	obj.b2 = 0; // Nicht erlaubt! Compilefehler.
	obj.b3 = 0; // Nicht erlaubt! Compilefehler.

	return 0;
}
