////////////////////////////////////////////////////////////
// Listing 157 aus Kapitel 2
// Typenkonvertierungsoperator nach bool

class X
{
	// ...
	operator bool();
};
