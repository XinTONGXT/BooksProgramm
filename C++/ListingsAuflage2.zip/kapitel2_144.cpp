////////////////////////////////////////////////////////////
// Listing 144 aus Kapitel 2
// Ausgabestreamoperator

std::ostream& operator<<( std::ostream &os,
                          const Complex &c )
{
	os << "(" << c.r << "/i" << c.i << ")";
	return os;
}
