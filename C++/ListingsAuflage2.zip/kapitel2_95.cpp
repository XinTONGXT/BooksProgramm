////////////////////////////////////////////////////////////
// Listing 95 aus Kapitel 2
// Ein mutable-Attribut

class X
{
	public:
		X() : a(0), b(0) {}

		void f() const
		{
			a = 0; // Nicht erlaubt!
			b = 0; // OK!
		}

		int a;
		mutable int b;
};

int main()
{
	const X obj;
	
	obj.a = 0; // Nicht erlaubt!
	obj.b = 0; // OK!

	return 0;
}
