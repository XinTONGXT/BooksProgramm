////////////////////////////////////////////////////////////
// Listing 65 aus Kapitel 4
// Reine Deklarations-Templates

// Vector.h
template <typename T>
class Vector
{
public:
	Vector(int c = 50, int d = 50);
	~Vector() { delete [] buf; }
	// ...
	void add( const T& );
	// ...
private:
	T *buf;	
	int size;
	int capacity;
	int delta;
};
