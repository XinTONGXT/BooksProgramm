////////////////////////////////////////////////////////////
// Listing 18 aus Kapitel 6
// Programm im ISO-C++-Stil

#include <iostream> // Neue Headerdatei
using namespace std; // Nur zur Anpassung alten Codes

// ...

int main()
{
	cout << "Eine angepasste Applikation"
	     << "im ANSI/ISO-Stil" << endl;
	// ...
	return 0;
}
