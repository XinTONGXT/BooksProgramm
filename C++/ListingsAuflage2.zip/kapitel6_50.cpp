////////////////////////////////////////////////////////////
// Listing 50 aus Kapitel 6
// Die Ringindex-Klasse mit volatile-Spezifikationen

class RingIndex
{
public:
	explicit RingIndex( unsigned int s )
	: max(s), actual(0) {}

	RingIndex( const volatile RingIndex& r )
	: max(r.max), actual(r.actual) {}

	void inc() volatile
	{
		if( actual == (max-1) )
			actual = 0;
		else
			actual++;
	}

	volatile RingIndex& operator++() volatile
	{
		inc();
		return *this;
	}

	RingIndex operator++(int) volatile
	{
		RingIndex tmp(*this);
		inc();
		return tmp;
	}

	operator unsigned int () const volatile
	{ return actual; }
	
private:
  unsigned int actual;
	const unsigned int max;
};
