////////////////////////////////////////////////////////////
// Listing 159 aus Kapitel 2
// �berladener Klammeroperator

class Command
{
public:
	// ...
	virtual bool operator()() = 0;
};
