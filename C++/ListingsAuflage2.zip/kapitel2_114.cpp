////////////////////////////////////////////////////////////
// Listing 114 aus Kapitel 2
// Elementsichtbarkeit bei standardm��ig privater Vererbung

class Basis
{
public:
	int b1;
protected:
	int b2;
private:
	int b3;
};
class S1 : Basis
{
public:
	void f();
};

void S1::f()
{
	b1 = 0; // OK
	b2 = 0; // OK
	b3 = 0; // Nicht erlaubt! Compilefehler.
}

int main()
{
	S1 obj;
	obj.b1 = 0; // Nicht erlaubt! Compilefehler.
	obj.b2 = 0; // Nicht erlaubt! Compilefehler.
	obj.b3 = 0; // Nicht erlaubt! Compilefehler.

	return 0;
}
