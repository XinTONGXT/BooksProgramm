////////////////////////////////////////////////////////////
// Listing 125 aus Kapitel 2
// Rein virtueller Destruktor

// Pseudocode
class Grafikelement
{
public:
	virtual ~Grafikelement() = 0;
	virtual void zeichne( Zeichenflaeche *zf ) = 0;
};

// In der CPP-Datei ist trotz der rein virtuellen
// Deklaration eine Implementierung notwendig!
Grafikelement::~Grafikelement() {}
