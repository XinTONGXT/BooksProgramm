////////////////////////////////////////////////////////////
// Listing 4 aus Kapitel 4
// min() als Makroimplementierung

#define min( a, b ) (((a)<(b))?(a):(b))
