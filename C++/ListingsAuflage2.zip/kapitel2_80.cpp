////////////////////////////////////////////////////////////
// Listing 80 aus Kapitel 2
// Speicherallokation im Konstruktor und Freigabe im Destruktor

typedef unsigned chat byte;

class Bitmap
{
	Bitmap( unsigned long s );
	~Bitmap();
// ...
private:
	byte *buffer;
	unsigned long size;
};

Bitmap::Bitmap( unsigned long s ) : size(s)
{
	buffer = new[size];
}

Bitmap::~Bitmap()
{
	delete [] buffer;
}
