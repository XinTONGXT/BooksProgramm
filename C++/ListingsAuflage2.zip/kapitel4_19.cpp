////////////////////////////////////////////////////////////
// Listing 19 aus Kapitel 4
// Vollst�ndige Spezialisierung einer Templateklasse

#define MEGAPIXEL  (1024*1024)

template <>
class Array<unsigned long, MEGAPIXEL>
{
public:
	Array() { data = new unsigned long [size]; }
	~Array() { delete [] data; }
	enum { size = MEGAPIXEL};
	unsigned long& operator[]( int i ) { return data[i]; }
	const unsigned long& max() const;
	const unsigned long& min() const;
private:
	unsigned long *data;
};

const unsigned long&
Array<unsigned long, MEGAPIXEL>::max() const
{
	const unsigned long* p = &data[0];
	for( int i = 1; i < size; ++i )
		if( *p < data[i] ) p = &data[i];
	return *p;
}

const unsigned long&
Array<unsigned long, MEGAPIXEL>::min() const
{
	const unsigned long* p = &data[0];
	for( int i = 1; i < size; ++i )
		if( *p > data[i] ) p = &data[i];
	return *p;
}
