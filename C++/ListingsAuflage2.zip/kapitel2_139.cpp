////////////////////////////////////////////////////////////
// Listing 139 aus Kapitel 2
// Auswirkung der Const-Maskierung

void IrgendwelcheBerechnungen( Kreis const &k )
{
// ...
	double u = k.Umfang() // Nur erlaubt, wenn Umfang()
	                      // const-modifiziert ist!
// ...
}
