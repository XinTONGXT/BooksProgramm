////////////////////////////////////////////////////////////
// Listing 33 aus Kapitel 5
// Der Algorithmus count_if

#include <iostream>
#include <list>
#include <algorithm>

bool test( int i )
{
    return (i % 2) == 0;
}

int main()
{
    using namespace std;

    list<int> l;

    l.push_back(  33 );
    l.push_back(  44 );
    l.push_back( 108 );
    l.push_back(  12 );

    int n = count_if( l.begin(), l.end(), test );
    cout << n << endl;

    return 0;
}
