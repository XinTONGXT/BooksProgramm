////////////////////////////////////////////////////////////
// Listing 19 aus Kapitel 6
// Globale �ffnung des Namensraums std

#include <iostream>
using namespace std;
	
int main()
{
	cout << "Hello world!" << endl;

	return 0;
}
