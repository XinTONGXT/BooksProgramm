////////////////////////////////////////////////////////////
// Listing 23 aus Kapitel 3
// Verschachtelte Klassen in der Listenimplementierung

// Liste.h
#ifndef __LISTE_H
#define __LISTE_H
class Listenelement
{
public:
	virtual ~Listenelement();
};

class Liste
{
private:
	typedef Listenelement* ELEMENT;

	class Knoten
	{
	public:
		Knoten( ELEMENT e )
		: element(e), prev(0), next(0) {}
		ELEMENT element;
		Knoten *prev, *next;
	};

public:	
	class Zugriff
	{
	public:
		Zugriff() : k(0) {}
		Zugriff( Knoten *pk ) : k(pk) {}
		void Inc() { k = k->next; }
		void Dec() { k = k->prev; }
		bool IsValid() const { return k != 0; }
		ELEMENT get() const { return k->element; }
	private:
		Knoten *k;
	};
	friend class Zugriff; // F�r die Verwendung von Knoten

	Liste() : anfang(0), ende(0) {}
	~Liste();
	void AddEnd( Listenelement *e );
	
	Zugriff Begin() { return Zugriff(anfang); }
	Zugriff End()   { return Zugriff(ende);   }
private:
	Knoten *anfang, *ende;
	Liste( const Liste & ); // verstecken!
};
#endif // __LISTE_H
// Ende von Liste.h
