////////////////////////////////////////////////////////////
// Listing 82 aus Kapitel 2
// Der Copy-Konstruktor

class X
{
public:
	X() {} // Standardkonstruktor
	X( const X & ) {} // Copy-Konstruktor
};
