////////////////////////////////////////////////////////////
// Listing 28 aus Kapitel 5
// Ein weiterer W�rterz�hler mit Streamiteratoren

#include <iostream>
#include <fstream>
#include <iterator>
#include <string>
#include <map>

int main()
{
	using namespace std;
	map<string,unsigned> wordmap;
	istream_iterator<string> ins( cin ), endofstream;

	while( ins != endofstream )
	{
		string word = *ins;
		wordmap[ word ] += 1;
		++ins;
	}

  for( map<string,unsigned>::
       iterator it=wordmap.begin();
	     it != wordmap.end(); ++it )
	{
		cout << it->first
		     << "\t"
		     << it->second
		     << endl;
	}

	return 0;
}
