////////////////////////////////////////////////////////////
// Listing 121 aus Kapitel 2
// Rein virtuelle Methode

// Pseudocode
class Grafikelement
{
public:
	virtual void zeichne( Zeichenflaeche *zf ) = 0;
};
