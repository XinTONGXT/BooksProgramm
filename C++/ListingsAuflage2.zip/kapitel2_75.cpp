////////////////////////////////////////////////////////////
// Listing 75 aus Kapitel 2
// Initialisierung eines konstanten Attributs

class Bitmap
{
public:
	Bitmap() : kachelgroesse(4096) {}
private:
	const unsigned long kachelgroesse;
};
