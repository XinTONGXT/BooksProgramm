////////////////////////////////////////////////////////////
// Listing 6 aus Kapitel 2
// Beispiel: bedingte Compilierung

#ifndef EXTC
 #ifdef __cplusplus
  #define EXTC extern "C"
 #else
  #define EXTC
 #endif
#endif // EXTC

EXTC int f()
{
	// ...
}
