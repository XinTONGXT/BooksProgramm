////////////////////////////////////////////////////////////
// Listing 30 aus Kapitel 5
// Der Algorithmus for_each

#include <iostream>
#include <set>
#include <algorithm>

void ausgabe( int i )
{
    std::cout << i << std::endl;
}

int main()
{
    using namespace std;

    set<int> s;

    s.insert( 3 );
    s.insert( 4 );
    s.insert( 1 );
    s.insert( 2 );

    for_each( s.begin(), s.end(), ausgabe );

    return 0;
}
