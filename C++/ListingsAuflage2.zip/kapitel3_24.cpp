////////////////////////////////////////////////////////////
// Listing 24 aus Kapitel 3
// Die Implementierung der Liste

// Liste.cpp
#include "Liste.h"

Listenelement::~Listenelement() {}

Liste::~Liste()
{
	Knoten *t = anfang;
	while( t )
	{
		Knoten *n = t->next;
		delete t;
		t = n;
	}
}

void Liste::AddEnd( Listenelement *e )
{
	Knoten *k = new Knoten( e );
	if( ende )
	{
		ende->next = k;
		k->prev = ende;
		ende = k;
	}
	else
	{
		anfang = ende = k;
	}
}
// Ende von Liste.cpp
