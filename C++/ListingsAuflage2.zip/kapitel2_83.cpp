////////////////////////////////////////////////////////////
// Listing 83 aus Kapitel 2
// Verwendung des Copy-Konstruktors bei der Initialisierung

// ...

int main()
{
	X obj1;         // Aufruf des Standardkonstruktors
	X obj2( obj1 ); // Aufruf des Copy-Konstruktors
	X obj3 = obj1;  // Noch einmal der Copy-Konstruktor

	return 0;
}
