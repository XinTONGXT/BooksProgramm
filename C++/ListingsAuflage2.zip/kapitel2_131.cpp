////////////////////////////////////////////////////////////
// Listing 131 aus Kapitel 2
// Mehrfachvererbung

class A { /*...*/ };
class B { /*...*/ };

class X : public A, public B
{ /*...*/ };
