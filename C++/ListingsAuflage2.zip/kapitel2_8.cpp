////////////////////////////////////////////////////////////
// Listing 8 aus Kapitel 2
// Detektion zur Compilezeit

#if defined( _WIN64 )
 #define MAXBUFFERSIZE 128000
#else
 #define MAXBUFFERSIZE  32000
#endif
