////////////////////////////////////////////////////////////
// Listing 3 aus Kapitel 4
// �berladene Versionen von min()

unsigned min( unsigned a, unsigned b )
{
	return ( a < b ) ? a : b;
}
double min( double a, double b )
{
	return ( a < b ) ? a : b;
}
