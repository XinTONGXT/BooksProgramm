////////////////////////////////////////////////////////////
// Listing 45 aus Kapitel 2
// Sicherung der dynamischen Speicherallokation

long *p;
p = (long *)malloc( 1000 * sizeof(long) );
if( p != 0 )
{
	...
	free(p);
}
