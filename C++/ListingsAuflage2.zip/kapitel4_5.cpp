////////////////////////////////////////////////////////////
// Listing 5 aus Kapitel 4
// Unerw�nschter Nebeneffekt bei der Verwendung eines Makros

#include <iostream>

#define min( a, b ) (((a)<(b))?(a):(b))

int main()
{
	int a = 5;
	int b = 4;

	std::cout << min( a, ++b ) << std::endl;

	return 0;
}
