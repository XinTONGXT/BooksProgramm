////////////////////////////////////////////////////////////
// Listing 63 aus Kapitel 4
// Explizite Instanziierung einer Template-Methode

template void X<int>::f();
