////////////////////////////////////////////////////////////
// Listing 72 aus Kapitel 4
// Rechenanweisungen f�r den Compiler

template <int X, int Y>
struct POWER
{
	enum { VALUE = X * POWER<X,Y-1>::VALUE };
};
template <int X>
struct POWER< X, 0 >
{
	enum { VALUE = 1 };
};
