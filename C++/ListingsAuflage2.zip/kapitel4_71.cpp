////////////////////////////////////////////////////////////
// Listing 71 aus Kapitel 4
// Typendetektion zur Compilezeit

template <typename T>
struct IsPointer
{
	enum { VALUE = false };
};
template <typename T>
struct IsPointer<T*>
{
	enum { VALUE = true };
};
