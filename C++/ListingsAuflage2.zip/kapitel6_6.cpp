////////////////////////////////////////////////////////////
// Listing 6 aus Kapitel 6
// Einbindung der Typeninformation erst bei Zugriff auf Klassenelementen von DBZugriff

// DBDialog.cpp
#include "DB.h"
#include "DBDialog.h" // Hier wird die vollst�ndige
                      // Typeninformation aufgenommen

void DBDialog::open()
{
	// Hier wird die Typeninformation gebraucht
	zugriff->init();
}
// Ende DBDialog.cpp
