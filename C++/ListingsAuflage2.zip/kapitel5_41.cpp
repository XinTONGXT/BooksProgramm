////////////////////////////////////////////////////////////
// Listing 41 aus Kapitel 5
// Ver�ndernder Algorithmus transform()

#include <iostream>
#include <list>
#include <algorithm>
#include <functional>

class ausgabe
{
public:
    ausgabe( std::ostream &s ) : os(s) {}
    void operator()( int i ) const
    { os << i << std::endl; }
private:
    std::ostream &os;
};

int main()
{
    using namespace std;

    list<int> l;

    l.push_back( 1 );
    l.push_back( 2 );
    l.push_back( 3 );

    for_each( l.begin(), l.end(), ausgabe(cout) );
    transform( l.begin(), l.end(),
               l.begin(), negate<int>() );
    for_each( l.begin(), l.end(), ausgabe(cout) );

    return 0;
}
