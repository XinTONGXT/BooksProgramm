////////////////////////////////////////////////////////////
// Listing 39 aus Kapitel 5
// Eine Modifikation des Pr�dikats

// ...
int n = count_if( l.begin(), l.end(),
                 not1(bind2nd(equal_to<int>(),3)));
// ...
