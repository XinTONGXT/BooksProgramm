////////////////////////////////////////////////////////////
// Listing 54 aus Kapitel 5
// Einfache Verwendung eines Valarrays

#include <iostream>
#include <valarray>

void print_out( const std::valarray<int> &va )
{
    for( unsigned i = 0; i < va.size(); ++i )
        std::cout << va[i] << std::endl;
}

int main()
{
    std::valarray<int> v(10);

    for( unsigned i = 0; i < 10; ++i )
        v[i] = 10 * (i+1);

    print_out( v );

    return 0;
}
