////////////////////////////////////////////////////////////
// Listing 44 aus Kapitel 6
// Zweites Beispiel zur Threadprogrammierung

#define STRICT
#include <windows.h>
#include <stdio.h>

volatile long n = 0;
CRITICAL_SECTION cs;

DWORD WINAPI ThreadFunc( LPVOID param )
{
	long i;
	for( i = 0; i < 1000000000; ++i )
	{
		EnterCriticalSection( &cs );
		n++;
		LeaveCriticalSection( &cs );
	}

	return 0;
}

int main( void )
{
	HANDLE hTh1, hTh2;
	InitializeCriticalSection( &cs );
	hTh1 = CreateThread( 0, 0, ThreadFunc, 0, 0, 0 );
	hTh2 = CreateThread( 0, 0, ThreadFunc, 0, 0, 0 );

	Sleep( 5000 );

	WaitForSingleObject( hTh1, INFINITE );
	WaitForSingleObject( hTh2, INFINITE );
	CloseHandle( hTh1 );
	CloseHandle( hTh2 );
	DeleteCriticalSection( &cs );

	printf( "Der Wert von n: %ld\n", n );

	return 0;
}
