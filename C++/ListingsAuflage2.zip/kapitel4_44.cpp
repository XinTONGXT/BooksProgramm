////////////////////////////////////////////////////////////
// Listing 44 aus Kapitel 4
// Template-Templateparameter

template< template <typename, typename> class T >
class X
{
};
