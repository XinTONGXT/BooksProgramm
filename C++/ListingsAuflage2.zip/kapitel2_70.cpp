////////////////////////////////////////////////////////////
// Listing 70 aus Kapitel 2
// Die Definition eines Konstruktors

// Klassendeklaration
class Punkt
{
public:
	Punkt( int vx, int vy );
	int x;
	int y;
};

// Methodendefinition
Punkt::Punkt( int vx, int vy )
{
	x = vx;
	y = vy;
}

// Instanziierung eines Objekts
Punkt p1( 5, 5,);
