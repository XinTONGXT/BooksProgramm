////////////////////////////////////////////////////////////
// Listing 143 aus Kapitel 2
// Anwendung eines �berladenen Operators

...
Complex z1 = {3,5};
Complex z2 = {2,1};

Complex z3 = z1 + z2;
...
