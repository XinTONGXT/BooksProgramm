////////////////////////////////////////////////////////////
// Listing 9 aus Kapitel 2
// Abbruch des Compilerlaufs bei Fehlerfall

#if defined( _WIN64 )
 #define MAXBUFFERSIZE 128000
#elif defined( _WIN32 )
 #define MAXBUFFERSIZE  32000
#else
 #error Kein 32 oder 64-Bit System!
#endif
