////////////////////////////////////////////////////////////
// Listing 165 aus Kapitel 2
// Implementierung der Methode what()

#include <iostream>
#include <string>
class MyException : public std::exception
{
public:
	MyException( char *where ) : txt(where) {}
	const char* what() const throw();
private:
	char *txt;
};

const char* MyException::what() const throw()
{
	static std::string s;
	s = "MyException ist in ";
	s += txt;
	s += " aufgetreten.";
	return s.c_str();
}

void f()
{
	throw MyException( "f() in Zeile soundso" );
}

int main()
{
	try
	{
		f();
	}
	catch( MyException &e )
	{
		std::cerr << e.what() << std::endl;
	}
	
	return 0;
}
