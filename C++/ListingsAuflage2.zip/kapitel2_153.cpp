////////////////////////////////////////////////////////////
// Listing 153 aus Kapitel 2
// Der �berladene Dereferenzierungsoperator

class FunctionalProxy
{
public:
	// ...
	Something& operator*();
private:
	Something *element;
};

Something& FunctionalProxy::operator*()
{
	// ...
	return *element;
}
