////////////////////////////////////////////////////////////
// Listing 128 aus Kapitel 2
// Korrekturcast bei fehlender const-Spezifikation

// ...
void foo( const Vector *v )
{
	Vector *p = const_cast<Vector*>(v);
	unsigned s = p->getSize();
// ...
}
