////////////////////////////////////////////////////////////
// Listing 45 aus Kapitel 6
// Die Ringindex-Klasse

class RingIndex
{
public:
	explicit RingIndex( unsigned int s )
	: max(s), actual(0) {}

	void inc()
	{
		if( actual == (max-1) )
			actual = 0;
		else
			actual++;
	}

	RingIndex& operator++()
	{
		inc();
		return *this;
	}

	RingIndex operator++(int)
	{
		RingIndex tmp(*this);
		inc();
		return tmp;
	}

	operator unsigned int () const { return actual; }

private:
	unsigned int actual;
	const unsigned int max;
};
