////////////////////////////////////////////////////////////
// Listing 16 aus Kapitel 2
// Zeigersyntax

	int i;
	int *p;
	p = &i;
	*p = 7;
	printf( "%d\n", i );
