////////////////////////////////////////////////////////////
// Listing 112 aus Kapitel 2
// Verweis eines Kindklassenobjekts mit einem Basisklassenzeiger

...
int main()
{
	Fahrzeug *p = new Schiff();

	...

	delete p;

	return 0;
}
