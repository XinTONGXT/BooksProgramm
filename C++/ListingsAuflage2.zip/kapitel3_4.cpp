////////////////////////////////////////////////////////////
// Listing 4 aus Kapitel 3
// Singleton mit privatem Standardkonstruktor

class Singleton
{
   public:
     static Singleton* exemplar();

     void fachlicheFunktion1();
     void fachlicheFunktion2();
     //...

   private:
     static Singleton *instanz;
     Singleton() {}
     Singleton( const Singleton& );
};

//...
