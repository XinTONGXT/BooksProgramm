////////////////////////////////////////////////////////////
// Listing 35 aus Kapitel 6
// Operator delete mit Sicherheitsabfrage

void  X::operator delete ( void *p, std::size_t s )
{
	if( s != sizeof(X) )
		::operator delete( p );
	else
		giveMemoryBackToPool( p );
}
