////////////////////////////////////////////////////////////
// Listing 100 aus Kapitel 2
// Anwendung des Scope-Operators beim Ansprechen von Bezeichnern

int x;

int main()
{
	int x;

	x = 5;	 // lokales x
	::x = 7; // globales x

// ...
}
