////////////////////////////////////////////////////////////
// Listing 10 aus Kapitel 6
// Verschachtelte Namensr�ume

namespace myLib
{
	namespace eventPart
	{
	// ...
	}
	namespace guiPart
	{
	// ...
	}
}
