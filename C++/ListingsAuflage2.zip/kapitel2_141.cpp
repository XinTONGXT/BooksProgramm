////////////////////////////////////////////////////////////
// Listing 141 aus Kapitel 2
// Komplexe Zahl als Strukturtyp

struct Complex
{
	double r;
	double i;
};
