////////////////////////////////////////////////////////////
// Listing 62 aus Kapitel 2
// Implementierung von Methoden

double Kreis::Umfang()
{
	return 2.0 * r * 3.141;
}

double Kreis::Flaeche()
{
	return 3.141 * r * r;
}
