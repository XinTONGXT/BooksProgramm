////////////////////////////////////////////////////////////
// Listing 30 aus Kapitel 4
// Aufruf einer �berschriebenen Basisklassenmethode durch Qualifizierung

...

int main()
{
	B b;
	b.A::f();

	return 0;
}
