////////////////////////////////////////////////////////////
// Listing 40 aus Kapitel 5
// Eine Umformung

// ...
int n = count_if( l.begin(), l.end(),
                 bind2nd(not_equal_to<int>(),3));
// ...
