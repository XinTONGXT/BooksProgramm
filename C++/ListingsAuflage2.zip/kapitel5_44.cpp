////////////////////////////////////////////////////////////
// Listing 44 aus Kapitel 5
// Rechenoperationen auf Mengen mit dem Algorithmus transform

// ...
int power( int x, int y )
{
    int ret = 1;
    while( y-- ) ret *= x;
    return ret;
}

int main()
{
    using namespace std;

    list<int> l1;
    list<int> l2;

    l1.push_back( 11 );
    l1.push_back(  7 );
    l1.push_back(  2 );

    l2.push_back( 2 );
    l2.push_back( 3 );
    l2.push_back( 7 );

    transform( l1.begin(), l1.end(),
               l2.begin(), l1.begin(), power );
    for_each( l1.begin(), l1.end(), ausgabe(cout) );

    return 0;
}
