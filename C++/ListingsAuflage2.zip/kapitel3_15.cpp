////////////////////////////////////////////////////////////
// Listing 15 aus Kapitel 3
// Gesicherte Copy-Konstruktoren

class Knoten
{
	// ...
private:
	Knoten( const Knoten & ); // verstecken!
};

class Liste
{
	// ...
private:
	Liste( const Liste & ); // verstecken!
};
