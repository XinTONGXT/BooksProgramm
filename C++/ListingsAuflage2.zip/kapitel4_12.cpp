////////////////////////////////////////////////////////////
// Listing 12 aus Kapitel 4
// Dynamische Instanziierung eines Objekts einer Templateklasse

// ...

Array<int, 5> *pa = new Array<int, 5>();

for( int i = 0; i < pa->size; ++i )
	(*pa)[i] = 0;
// ...
delete pa;
// ...
