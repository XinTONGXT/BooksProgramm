////////////////////////////////////////////////////////////
// Listing 50 aus Kapitel 4
// Der Test des Mappings

int main()
{
    Mapping<int,std::string,std::list> m;
    //...
}
