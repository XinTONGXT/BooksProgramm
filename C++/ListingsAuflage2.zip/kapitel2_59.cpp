////////////////////////////////////////////////////////////
// Listing 59 aus Kapitel 2
// Klassenattribute

class Kreis
{
public:
	int x, y;      // Attribute
	double radius; // Attribut
};
