////////////////////////////////////////////////////////////
// Listing 17 aus Kapitel 5
// Kurze Demonstration der STL-Liste

#include <iostream>
#include <list>

int main()
{
	std::list<int> l;

	l.push_back( 3 );
	l.push_back( 5 );
	l.push_back( 7 );

	for( std::list<int>::iterator it = l.begin();
	     it != l.end();
	     ++it )
	     std::cout << *it << std::endl;

	return 0;
}
