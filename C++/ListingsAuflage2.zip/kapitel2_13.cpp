////////////////////////////////////////////////////////////
// Listing 13 aus Kapitel 2
// Zeigersyntax

	int i;
	int *p;
	double d;
	double *pd;
	/* ... */
	p = &i;   // Zuweisung der Adresse von i.
	pd = &d;  // Zuweisung der Adresse von d.
