////////////////////////////////////////////////////////////
// Listing 17 aus Kapitel 4
// Instanziierung eines Templates durch eine Typendefinition

// ...
typedef Array<int,5> INTARRAY5;
// ...
