////////////////////////////////////////////////////////////
// Listing 63 aus Kapitel 2
// Methodenzugriff

Kreis k1;
k1.x = 0;
k1.y = 0;
k1.r = 2;
double u = k1.Umfang();
double f = k1.Flaeche();
