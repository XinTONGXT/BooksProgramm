////////////////////////////////////////////////////////////
// Listing 53 aus Kapitel 4
// Eine Templateimplementierung des Vektors

template <typename T>
class Vektor
{
	typedef T ELEMENT;
public:
	Vektor()
	: size(0),
		capacity(STANDARDCAPACITY),
		delta(STANDARDDELTA)
		{ Init();}
	Vektor( unsigned k = 10, unsigned d = 10 )
	: size(0),
		capacity(k>0?k:1),
		delta(d>0?d:1)
		{ Init();}

	~Vektor() { delete [] buf; }

	void AddEnd( ELEMENT e )
	{
		if( size == capacity )
	  	Grow();
	  buf[size++] = e;
	}

	const ELEMENT& GetAt( unsigned idx ) const
	{
		return buf[idx];
	}
	const ELEMENT& operator[]( unsigned idx ) const
	{
		return buf[idx];
	}
	ELEMENT& GetAt( unsigned idx )
	{
		return buf[idx];
	}
	ELEMENT& operator[]( unsigned idx )
	{
		return buf[idx];
	}

	unsigned Size() const { return size; }

private:
	unsigned size;
	unsigned capacity;
	unsigned delta;
	ELEMENT *buf;
	enum { STANDARDCAPACITY = 10 };
	enum { STANDARDDELTA = 10      };
	void Init() { buf = new ELEMENT[ capacity ]; }
	void Grow();
};

template <typename T>
void Vektor<T>::Grow()
{
	unsigned newcapacity = capacity + delta;
	ELEMENT *newbuf = new ELEMENT[newcapacity];
	for( unsigned i = 0; i < size; ++i )
		newbuf[i] = buf[i];
	delete [] buf;
	buf = newbuf;
	capacity = newcapacity;
}
