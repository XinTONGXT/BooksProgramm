////////////////////////////////////////////////////////////
// Listing 51 aus Kapitel 5
// Initialisierung aus einer Containersequenz

#include <iostream>
#include <string>
#include <list>

int main()
{
    using namespace std;

    list<char> l;
    l.push_back( 'T' );
    l.push_back( 'e' );
    l.push_back( 'x' );
    l.push_back( 't' );

    string s( l.begin(), l.end() );

    cout << s << endl;

    return 0;
}
