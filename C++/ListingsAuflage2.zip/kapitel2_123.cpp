////////////////////////////////////////////////////////////
// Listing 123 aus Kapitel 2
// Virtueller Destruktor

class Basis
{
public:
	virtual ~Basis();
};

class Spezialisierung : public Basis
{
public:
	~Spezialisierung();
};

// Typischer leerer Destruktor einer Basisklasse.
Basis::~Basis() {}

Spezialisierung::~Spezialisierung()
{
 // Dieser Destruktor hat eventuell etwas zu tun.
}

int main()
{
	Basis *obj = new Spezialisierung();
	
	delete obj;
	
	return 0;
}
