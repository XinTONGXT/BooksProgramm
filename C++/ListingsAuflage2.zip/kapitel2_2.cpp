////////////////////////////////////////////////////////////
// Listing 2 aus Kapitel 2
// Verzweigungen im Pr�prozessorlauf

#if   DEBUG == 1
	void TraceOut( char *txt )
	{
		std::cerr << txt << std::endl;
	}
#elif DEBUG == 2
	void TraceOut( char *txt )
	{
		writeToFile( "TRACES.TXT", txt );
	}
#else
	inline void TraceOut( char * )
	{
	}
#endif
