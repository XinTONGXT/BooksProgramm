////////////////////////////////////////////////////////////
// Listing 15 aus Kapitel 2
// Zeigersyntax

	int i;
	int *p;
	p = &i;
	i =7;
	printf( "%d\n", *p );
