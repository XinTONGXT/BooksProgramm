////////////////////////////////////////////////////////////
// Listing 156 aus Kapitel 2
// Allgemeine Form eines Typenkonvertierungsoperators

class Quelltyp
{
	// ...
	operator Zieltyp();
};
