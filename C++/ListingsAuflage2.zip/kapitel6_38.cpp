////////////////////////////////////////////////////////////
// Listing 38 aus Kapitel 6
// Schematische Implementierung zur Persistenz

class Punkt : public PersistenzObjekt
{
public:
  // ...

	void schreibe( std::ostream & );

private:
	int x, y;
};

void Punkt::schreiben( std::ostream &os )
{
	os << "Typ: Punkt" << std::endl;
	os << x << std::endl;
	os << y << std::endl;
}
