
Dieses Verzeichnis enth�lt die Listings zum Buch

 R. Schneewei�
 Moderne C++ Programmierung, 2. Auflage
 ISBN Nummer 978-3-642-21428-8

 erschienen im August 2012 
 beim Springer-Verlag GmbH Heidelberg

Bei den Listings handelt es sich zum Teil um ablauff�hige
Beispiele. Der andere Teil stellt eine Sammlung von Code-
schnipseln dar, die spezielle Eigenschaften von C++ und
der Standardbobliothek zeigen sollen. Diese Teile k�nnen
ver�ndert und - IN EIGENER VERANTWORTUNG - in andere Quellcodes
eingebaut werden. Es ist davon auszugehen, das die Codes
Fehler enthalten k�nnen.

Haftungsausschluss:
Es versteht sich von selbst, dass f�r die Codebeispiele
keine Haftung �bernommen werden kann, wenn diese in 
Software eingebaut und verwendet werden. Eine solche
�bernahme von Codes geschieht grunds�tzlich in eigener
Verantwortung. Insbesondre sind die Codes nicht f�r 
sicherheitskritische Anwendungen in den Bereichen Luft-
und Raumfahrt sowie der Nukleartechnik entwickelt worden.


T�bingen, 30.September.2012 R. Schneewei�

