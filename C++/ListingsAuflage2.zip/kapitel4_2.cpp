////////////////////////////////////////////////////////////
// Listing 2 aus Kapitel 4
// Eine weitere traditionelle Implementierung von min()

int min( int a, int b )
{
	return ( a < b ) ? a : b;
}
