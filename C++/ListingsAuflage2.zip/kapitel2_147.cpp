////////////////////////////////////////////////////////////
// Listing 147 aus Kapitel 2
// �berladener Operator als Klassenelement

class Complex
{
public:
	double r;
	double i;

	Complex operator+( const Complex &c ) const;
};

Complex Complex::operator+( const Complex &c ) const
{
	Complex result;	
	result.r = r + c.r;
	result.i = i + c.i;
	return result;
}
