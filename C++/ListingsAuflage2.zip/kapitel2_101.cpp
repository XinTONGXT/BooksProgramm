////////////////////////////////////////////////////////////
// Listing 101 aus Kapitel 2
// Qualifizierung durch den Scope-Operator

class A
{
public:
	void f()
	{
	// ...
	}
};

class B : public A
{
public:
	void f() // �berschreibt f() aus A
	{
		A::f(); // ruft f() aus A
		// ...
	}
};

int main()
{
	B b;

	b.f();    // ruft f() aus B
	b.A::f(); // ruft f() aus A

	// ...
}
