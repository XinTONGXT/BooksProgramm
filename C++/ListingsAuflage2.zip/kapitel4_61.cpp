////////////////////////////////////////////////////////////
// Listing 61 aus Kapitel 4
// Allgemeines Klassentemplate

template <typename T>
class X
{
public:
	void f();
};

template <typename T>
void X<T>::f()
{
}
