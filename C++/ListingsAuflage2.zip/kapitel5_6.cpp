////////////////////////////////////////////////////////////
// Listing 6 aus Kapitel 5
// Anwendung der Methode get() zum Einlesen aller Zeichen

// Streambeispiel6.cpp
#include <iostream>

int main()
{
	char c;
	while( std::cin.get( c ) )
		std::cout << c;

	return 0;
}
