////////////////////////////////////////////////////////////
// Listing 14 aus Kapitel 4
// Separate Templates f�r die Methodenimplementierungen

template <typename T, unsigned n>
const T& Array<T,n>::max() const
{
	const T* p = &data[0];
	for( int i = 1; i < size; ++i )
		if( *p < data[i] ) p = &data[i];
	return *p;
}

template <typename T, unsigned n>
const T& Array<T,n>::min() const
{
	const T* p = &data[0];
	for( int i = 1; i < size; ++i )
		if( *p > data[i] ) p = &data[i];
	return *p;
}
