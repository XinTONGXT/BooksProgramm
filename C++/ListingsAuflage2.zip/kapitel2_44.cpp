////////////////////////////////////////////////////////////
// Listing 44 aus Kapitel 2
// Dynamische Allokation von Speicher in C

long *p;
p = (long *)malloc( 1000 * sizeof(long) );
...

...
free(p);
