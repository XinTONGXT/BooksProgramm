////////////////////////////////////////////////////////////
// Listing 13 aus Kapitel 6
// Integration eines Elementes aus einem fremden Namensraum

namespace myPrj
{
	using std::string;
}
