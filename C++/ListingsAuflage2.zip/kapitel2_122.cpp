////////////////////////////////////////////////////////////
// Listing 122 aus Kapitel 2
// Implementierung einer rein virtuellen Methode in einer Kindklasse

// Pseudocode
class Linie : public Grafikelement
{
public:
	Linie( const Punkt &a, const Punkt &e )
	: p1(a), p2(e) {}
	void zeichne( Zeichenflaeche *zf );
private:
	Punkt p1, p2;
};

void Linie::zeichne( Zeichenflaeche *zf )
{
	zf->positioniere( p1.x, p1.y );
	zf->zeichneLinie( p2.x, p2.y );
}
