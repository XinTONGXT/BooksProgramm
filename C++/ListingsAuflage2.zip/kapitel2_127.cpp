////////////////////////////////////////////////////////////
// Listing 127 aus Kapitel 2
// Fehlende const-Spezifikation

class Vector
{
// ...
public:
	unsigned getSize() { return size; }
private:
	unsigned size;
// ...
};

void foo( const Vector *v )
{
	unsigned s = v->getSize(); // Fehler!
// ...
}
