////////////////////////////////////////////////////////////
// Listing 22 aus Kapitel 4
// Anwendung von Grundtemplate und spezialisiertem Template

// ...
Array<int, 5> a1;
Array<int*,5> a2;
// ...
