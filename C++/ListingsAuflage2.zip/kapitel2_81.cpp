////////////////////////////////////////////////////////////
// Listing 81 aus Kapitel 2
// Der Standardkonstruktor

#include <iostream>

class A
{
public:
	A() { std::cout << "A::A()" << std::endl; }
};

class B : public A
{
};

int main()
{
	B b;
	return 0;
}
