////////////////////////////////////////////////////////////
// Listing 13 aus Kapitel 5
// Einfaches Kopierprogramm mit File-Streams

#include <fstream>

int main(int argc, char *argv[])
{
	using namespace std;

	if( argc != 3 ) return 0;

	ifstream in( argv[1], ios::binary | ios::in );
	ofstream out( argv[2], ios::binary | ios::out );

	if( in && out )
	{
		char c;
		while( in.get( c ) )
			out.put( c );
	}

	return 0;
}
