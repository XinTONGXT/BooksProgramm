////////////////////////////////////////////////////////////
// Listing 9 aus Kapitel 5
// Formatierung �ber Manipulatoren

#include <iostream>

int main()
{
	using namespace std;
	int i = 42;

	cout << oct << i << endl;
	cout << hex << i << endl;
	cout << dec << i << endl;
	return 0;
}
