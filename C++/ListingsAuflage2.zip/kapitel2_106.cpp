////////////////////////////////////////////////////////////
// Listing 106 aus Kapitel 2
// Private verschachtelte Klasse

class Citroen
{
	// ...
private:
	class CitroenLuftfederung
	{
		// ...
	};
};
