////////////////////////////////////////////////////////////
// Listing 3 aus Kapitel 5
// Anwendung des definierten Ausgabeoperators auf verschiedene Streams

#include <iostream>
#include <fstream>

struct Complex
{
	double r;
	double i;
};
std::ostream& operator<<( std::ostream &os,
                          const Complex &c )
{
	os << "(" << c.r << "/i" << c.i << ")";
	return os;
}

int main()
{
	Complex c = { 5, 3 };

	std::cout << "Eine Komplexe Zahl: " << c << std::endl;

	std::ofstream datei( "test.txt" );
	datei << "Eine Komplexe Zahl: " << c << std::endl;

	return 0;
}
