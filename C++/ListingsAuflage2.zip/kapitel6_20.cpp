////////////////////////////////////////////////////////////
// Listing 20 aus Kapitel 6
// Lokale �ffnung des Namensraums std

#include <iostream>

int main()
{
	using namespace std;

	cout << "Hello world!" << endl;

	return 0;
}
