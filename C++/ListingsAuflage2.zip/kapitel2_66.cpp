////////////////////////////////////////////////////////////
// Listing 66 aus Kapitel 2
// Die Sichtbarkeiten von Klassenelementen

class X
{
	int a; // a ist privat wie d
public:
	int b;
protected:
	int c;
private:
	int d;
};
