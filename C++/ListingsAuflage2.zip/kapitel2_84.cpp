////////////////////////////////////////////////////////////
// Listing 84 aus Kapitel 2
// Copy-Konstruktoraufruf bei Werte�bergabe an eine Funktion

// ...

void f( X obj )
{
	// ...
}

int main()
{
	X obj1; // Standardkonstruktoraufruf
	
	f( obj1 ); // Aufruf des Copy-Konstruktors
	
	return 0;
}
