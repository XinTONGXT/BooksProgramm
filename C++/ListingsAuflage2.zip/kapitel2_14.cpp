////////////////////////////////////////////////////////////
// Listing 14 aus Kapitel 2
// Zeigersyntax

	int i;
	int *p1;
	int *p2;
	/* ... */
	p1 = &i;
	p2 = p1; /* Die Adresse aus p1 wird p2 zugewiesen. */
