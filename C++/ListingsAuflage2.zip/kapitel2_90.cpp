////////////////////////////////////////////////////////////
// Listing 90 aus Kapitel 2
// Automatische Instanziierungen

#include <iostream>
using namespace std;
class X
{
public:
	X() { cout << "X::X()" << endl; }
	~X() { cout << "X::~X()" << endl; }
};

void f()
{
	X x; // automatische Instanziierung
	cout << "Anfang Block innerhalb f()" << endl;
	{
		X x; // automatische Instanziierung
		// ...
	}
	cout << "Ende Block innerhalb f()" << endl;
}

int main()
{
	auto X x; // automatische Instanziierung
	          // das Schl�sselwort auto ist optional
	cout << "Aufruf von f()" << endl;
	f();
	cout << "Nach dem Aufruf von f()" << endl;
	return 0;
}
