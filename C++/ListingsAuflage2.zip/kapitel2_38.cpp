////////////////////////////////////////////////////////////
// Listing 38 aus Kapitel 2
// Ein Funktionszeiger

int f( int , double  )
{
  return 0;
}

int (*fp)(int,double); // Funktionszeiger
