////////////////////////////////////////////////////////////
// Listing 60 aus Kapitel 4
// Teilimplementierung eines Template-basierten Vektors

template <typename T>
class Vector
{
public:
	Vector(int c = 50, int d = 50);
	~Vector() { delete [] buf; }
	// ...
	void add( const T& );
	// ...
private:
	T *buf;	
	int size;
	int capacity;
	int delta;
};

template <typename T>
Vector<T>::Vector( int c, int d )
: capacity(c), delta(d), size(0)
{
	if( this->delta <= 0 ) this->delta = 1;
	this->buf = new T[c];
}

template <typename T>
void Vector<T>::add( const T& t )
{
	if( this->size == this->capacity )
	{
		int newcapacity = this->capacity + this->delta;
		T* newbuf = new T[newcapacity];
		for( int i = 0; i < this->capacity; i++ )
			newbuf[i] = this->buf[i];
		delete [] this->buf;
		this->buf = newbuf;
		this->capacity = newcapacity;
	}
	this->buf[this->size++] = t;
}
