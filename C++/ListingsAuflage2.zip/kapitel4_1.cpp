////////////////////////////////////////////////////////////
// Listing 1 aus Kapitel 4
// Eine traditionelle Implementierung der Funktion min()

int min( int a, int b )
{
	if( a < b ) return a;
	return b;
}
