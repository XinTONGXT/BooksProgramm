////////////////////////////////////////////////////////////
// Listing 134 aus Kapitel 2
// Rautenf�rmige Vererbungshierarchie

class A { /*...*/ };

class B1 : public A { /*...*/ };
class B2 : public A { /*...*/ };

class C : public B1, public B2 { /*...*/ };

int main()
{
    B1 b1;
    C c;

    A *p1 = &b1;
    A *p2 = &c;   // Nicht erlaubt!

    return 0;
}
