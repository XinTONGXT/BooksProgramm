////////////////////////////////////////////////////////////
// Listing 7 aus Kapitel 6
// Syntax der Namensr�ume

namespace myLib
{
	class X { /* ... */ };
	struct Y { /* ... */ };
	typedef /* ... */ Z;
}
