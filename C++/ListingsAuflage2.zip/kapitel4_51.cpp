////////////////////////////////////////////////////////////
// Listing 51 aus Kapitel 4
// Eine Templateimplementierung der verketteten Liste

// Liste.h
#ifndef __LISTE_H
#define __LISTE_H

template <typename T>
class Liste
{
private:
	typedef T ELEMENT;

	class Knoten
	{
	public:
		Knoten( ELEMENT e )
		: element(e), prev(0), next(0) {}
		ELEMENT element;
		Knoten *prev, *next;
	};

public:	
	class Zugriff
	{
	public:
		Zugriff() : k(0) {}
		Zugriff( Knoten *pk ) : k(pk) {}
		void Inc() { k = k->next; }
		void Dec() { k = k->prev; }
		bool IsValid() const { return k != 0; }
		ELEMENT get() const { return k->element; }
	private:
		Knoten *k;
	};
	friend class Zugriff; // F�r die Verwendung von Knoten

	Liste() : anfang(0), ende(0) {}
	~Liste();
	void AddEnd( const T & );

	Zugriff Begin() { return Zugriff(anfang); }
	Zugriff End()   { return Zugriff(ende);   }
private:
	Knoten *anfang, *ende;
	Liste( const Liste & ); // verstecken!
};
template <typename T>
Liste<T>::~Liste()
{
	Knoten *t = anfang;
	while( t )
	{
		Knoten *n = t->next;
		delete t;
		t = n;
	}
}

template <typename T>
void Liste<T>::AddEnd( const T &e )
{
	Knoten *k = new Knoten( e );
	if( ende )
	{
		ende->next = k;
		k->prev = ende;
		ende = k;
	}
	else
	{
		anfang = ende = k;
	}
}
#endif // __LISTE_H
// Ende von Liste.h
