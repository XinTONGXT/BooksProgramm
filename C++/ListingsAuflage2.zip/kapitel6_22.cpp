////////////////////////////////////////////////////////////
// Listing 22 aus Kapitel 6
// Schritt 2: Woher kommt der Ausgabeoperator?

#include <iostream>
#include <string>
	
int main()
{
	std::string str = "Na sowas!";

	operator<<(std::cout,str);

	return 0;
}
