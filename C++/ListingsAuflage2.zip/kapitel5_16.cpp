////////////////////////////////////////////////////////////
// Listing 16 aus Kapitel 5
// Anwendung von Iteratoren in der STL

#include <iostream>
#include <list>

typedef std::list<int> Container;

void print_out( const Container &c )
{
    for( Container::const_iterator it = c.begin();
         it != c.end(); ++it )
        std::cout << *it;
    std::cout << std::endl;
}

void print_reverse( const Container &c )
{
    for( Container::const_reverse_iterator it
                                = c.rbegin();
         it != c.rend(); ++it )
        std::cout << *it;
    std::cout << std::endl;
}

int main()
{
    Container l;

    l.push_back( 3 );
    l.push_back( 5 );
    l.push_back( 7 );

    print_out(l);
    print_reverse(l);

    return 0;
}
