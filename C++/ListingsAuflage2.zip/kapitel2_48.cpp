////////////////////////////////////////////////////////////
// Listing 48 aus Kapitel 2
// Dynamische Allokation eines einzelnen Objekts

long *p = NULL;
try
{
	p = new long(42);
	std::cout << *p << std::endl;
}
catch( std::bad_alloc &e )
{
}

...
delete p;
