////////////////////////////////////////////////////////////
// Listing 70 aus Kapitel 4
// Compilezeitbedingungen mit Templates

template <bool COND, typename A, typename B>
struct IF
{
	typedef A RETURN;
};
template <typename A, typename B>
struct IF<false, A, B>
{
	typedef B RETURN;
};
