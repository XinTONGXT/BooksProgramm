////////////////////////////////////////////////////////////
// Listing 94 aus Kapitel 2
// Statische Variable in einer Funktion

unsigned int globaler_zaehler()
{
	// Wird nur einmal initialisiert!
	static unsigned int z = 0;

	// Wird bei jedem Funktionsdurchlauf inkrementiert.
	z++;

	return z;
}
