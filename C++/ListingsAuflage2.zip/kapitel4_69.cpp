////////////////////////////////////////////////////////////
// Listing 69 aus Kapitel 4
// Verwendung des Schl�sselworts export

// Vector.h
export template <typename T>
class Vector
{
public:
	Vector(int c = 50, int d = 50);
	~Vector() { delete [] buf; }
	// ...
	void add( const T& );
	// ...
private:
	T *buf;
	int size;
	int capacity;
	int delta;
};
