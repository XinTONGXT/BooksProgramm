////////////////////////////////////////////////////////////
// Listing 67 aus Kapitel 4
// Instanziierung und Verwendung der Typeninformation

#include "Vector.h"

int main()
{
	// Hier wird nur die Typeninformation instanziiert.
	Vector<int> v();

	// ...

	return 0;
}
