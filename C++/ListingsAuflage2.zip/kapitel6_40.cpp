////////////////////////////////////////////////////////////
// Listing 40 aus Kapitel 6
// Konstruktor zum Einlesen eines Objekts

Punkt::Punkt( std::istream &is )
{
	is >> x;
	is >> y;
}
